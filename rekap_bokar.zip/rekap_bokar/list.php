<?php
// list.php - Halaman Kelola Harga Harian PT Potensi Bumi Sakti
// Lokasi server: potensibumisakti/purchasing-system/harga-harian/list.php

// --------------------------------------------------------
// 1. KONEKSI DATABASE (Sesuaikan dengan config.php Anda)
// --------------------------------------------------------
// Kita berasumsi file config berada dua tingkat di atas (../../config.php)
// atau Anda bisa menulis koneksi database langsung seperti di bawah ini:
$db_host = '127.0.0.1';
$db_name = 'abdulkar_rekap_bokar'; // nama database Anda
$db_user = 'abdulkar_pbs';         // username database Anda
$db_pass = 'arsari-group';         // password database Anda

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Simulasi user login untuk demo (Jika di sistem asli Anda, ini diambil dari session login)
if (!isset($_SESSION['fullname'])) {
    $_SESSION['fullname'] = 'Bagus Julianto';
    $_SESSION['role'] = 'Petugas (Approval)';
    $_SESSION['user_id'] = 1;
}

$flash_message = '';
$flash_type = '';

// --------------------------------------------------------
// 2. HANDLER: HAPUS RIWAYAT HARGA (GET - FITUR BARU!)
// --------------------------------------------------------
if (isset($_GET['delete_id'])) {
    $delete_id = (int)$_GET['delete_id'];
    
    try {
        // Ambil info harga untuk catatan log sebelum dihapus
        $stmt = $pdo->prepare("SELECT daerah, harga_kg FROM harga_harian WHERE id = ?");
        $stmt->execute([$delete_id]);
        $row = $stmt->fetch();
        
        if ($row) {
            $daerah = $row['daerah'];
            $harga = number_format($row['harga_kg'], 0, ',', '.');
            
            $stmt = $pdo->prepare("DELETE FROM harga_harian WHERE id = ?");
            $stmt->execute([$delete_id]);
            
            $_SESSION['flash'] = [
                'type' => 'success',
                'text' => "Berhasil menghapus harga harian untuk Daerah $daerah sebesar Rp $harga!"
            ];
        } else {
            $_SESSION['flash'] = ['type' => 'error', 'text' => "Data harga tidak ditemukan."];
        }
    } catch (PDOException $e) {
        $_SESSION['flash'] = ['type' => 'error', 'text' => "Gagal menghapus data: " . $e->getMessage()];
    }
    header("Location: list.php");
    exit;
}

// --------------------------------------------------------
// 3. HANDLER: TAMBAH / UPDATE HARGA HARIAN (POST)
// --------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action === 'add' || $action === 'edit') {
        $daerah = trim($_POST['daerah']);
        $harga_kg = (double)$_POST['harga_kg'];
        $catatan = trim($_POST['catatan']) ?: '-';
        $tanggal = $_POST['tanggal'] ?: date('Y-m-d');
        
        if (!empty($daerah) && $harga_kg > 0) {
            try {
                if ($action === 'add') {
                    // Tambah Baru
                    $stmt = $pdo->prepare("INSERT INTO harga_harian (tanggal, daerah, harga_kg, catatan, ditetapkan_oleh, terakhir_diubah) VALUES (?, ?, ?, ?, ?, NOW())");
                    $stmt->execute([$tanggal, $daerah, $harga_kg, $catatan, $_SESSION['fullname']]);
                    $_SESSION['flash'] = ['type' => 'success', 'text' => "Harga harian untuk $daerah berhasil ditetapkan!"];
                } else {
                    // Update Edit
                    $id = (int)$_POST['id'];
                    $stmt = $pdo->prepare("UPDATE harga_harian SET tanggal = ?, daerah = ?, harga_kg = ?, catatan = ?, ditetapkan_oleh = ?, terakhir_diubah = NOW() WHERE id = ?");
                    $stmt->execute([$tanggal, $daerah, $harga_kg, $catatan, $_SESSION['fullname'], $id]);
                    $_SESSION['flash'] = ['type' => 'success', 'text' => "Harga harian untuk $daerah berhasil diperbarui!"];
                }
            } catch (PDOException $e) {
                $_SESSION['flash'] = ['type' => 'error', 'text' => "Gagal menyimpan data: " . $e->getMessage()];
            }
        } else {
            $_SESSION['flash'] = ['type' => 'error', 'text' => "Harap isi kolom daerah dan harga dengan benar."];
        }
        header("Location: list.php");
        exit;
    }
}

// Ambil flash session jika ada
if (isset($_SESSION['flash'])) {
    $flash_message = $_SESSION['flash']['text'];
    $flash_type = $_SESSION['flash']['type'];
    unset($_SESSION['flash']);
}

// --------------------------------------------------------
// 4. BUAT TABEL DATABASE OTOMATIS (Jika Belum Ada)
// --------------------------------------------------------
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `harga_harian` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `tanggal` date NOT NULL,
        `daerah` varchar(100) NOT NULL,
        `harga_kg` double NOT NULL,
        `catatan` text DEFAULT '-',
        `ditetapkan_oleh` varchar(100) NOT NULL,
        `terakhir_diubah` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    
    // Seed harga contoh harian jika tabel kosong (Sesuai persis dengan screenshot Anda!)
    $count = $pdo->query("SELECT COUNT(*) FROM harga_harian")->fetchColumn();
    if ($count == 0) {
        $pdo->exec("INSERT INTO harga_harian (id, tanggal, daerah, harga_kg, catatan, ditetapkan_oleh, terakhir_diubah) VALUES
            (1, '2026-08-10', 'Pabrik', 35000.0, '-', 'Yasro', '2026-08-10 14:54:00'),
            (2, '2026-08-10', 'Aceh Barat', 34700.0, '-', 'Yasro', '2026-08-10 14:54:00'),
            (3, '2026-08-10', 'Nagan Raya', 34600.0, '-', 'Yasro', '2026-08-10 14:55:00'),
            (4, '2026-08-10', 'Aceh Jaya', 34500.0, '-', 'Yasro', '2026-08-10 14:56:00'),
            (5, '2026-08-10', 'Umum', 67000.0, '-', 'Bagus Julianto', '2026-08-10 14:59:00');");
    }
} catch (PDOException $e) {
    // Abaikan
}

// --------------------------------------------------------
// 5. AMBIL DATA HARGA DARI DATABASE
// --------------------------------------------------------
$stmt = $pdo->query("SELECT * FROM harga_harian ORDER BY tanggal DESC, daerah ASC");
$prices = $stmt->fetchAll();

// Ambil harga hari ini untuk daerah "Aceh Barat" sebagai harga utama di atas (Sesuai screenshot Anda!)
$today_price_formatted = "Rp 0";
$today_setter = "-";
$today_time = "-";

foreach ($prices as $p) {
    if ($p['tanggal'] === date('Y-m-d') && $p['daerah'] === 'Aceh Barat') {
        $today_price_formatted = "Rp " . number_format($p['harga_kg'], 0, ',', '.');
        $today_setter = $p['ditetapkan_oleh'];
        $today_time = date('d.m.Y H:i', strtotime($p['terakhir_diubah']));
        break;
    }
}
// Fallback jika tidak ada record hari ini
if ($today_price_formatted === "Rp 0" && !empty($prices)) {
    $today_price_formatted = "Rp " . number_format($prices[0]['harga_kg'], 0, ',', '.');
    $today_setter = $prices[0]['ditetapkan_oleh'];
    $today_time = date('d.m.Y H:i', strtotime($prices[0]['terakhir_diubah']));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harga Harian (Notaring / Kering) - PT Potensi Bumi Sakti</title>
    <!-- Tailwind CSS CDN -->
    <link rel="stylesheet" href="assets/css/tailwind.css">
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <style>
        .sidebar-active {
            background-color: #16a34a;
            color: white;
        }
    </style>
</head>
<body class="bg-gray-100 font-sans text-xs sm:text-sm">

    <!-- Top Navbar (Sesuai persis dengan screenshot!) -->
    <header class="bg-[#1e293b] text-white py-3 px-4 flex justify-between items-center shadow-md">
        <div class="flex items-center space-x-2">
            <i class="fa-solid fa-truck-moving text-xl text-green-500"></i>
            <span class="text-base font-bold tracking-wider">Purchasing System</span>
        </div>
        
        <div class="flex items-center space-x-4 text-xs">
            <div class="flex items-center space-x-2">
                <i class="fa-solid fa-circle-user text-lg text-gray-300"></i>
                <span><?php echo htmlspecialchars($_SESSION['fullname']); ?></span>
                <span class="bg-[#334155] px-2 py-0.5 rounded-full text-[10px] font-bold"><?php echo htmlspecialchars($_SESSION['role']); ?></span>
            </div>
            <a href="../../logout.php" class="bg-red-600 hover:bg-red-700 text-white font-bold px-3 py-1.5 rounded flex items-center gap-1">
                <i class="fa-solid fa-right-from-bracket text-[10px]"></i> Keluar
            </a>
        </div>
    </header>

    <div class="flex min-h-screen">
        
        <!-- Left Sidebar (Sesuai persis dengan screenshot!) -->
        <aside class="w-56 bg-[#0f172a] text-gray-300 p-4 space-y-4 flex-shrink-0">
            <nav class="space-y-1 text-xs font-semibold">
                <a href="../dashboard.php" class="flex items-center space-x-2.5 px-3 py-2.5 rounded-lg hover:bg-[#1e293b] hover:text-white transition">
                    <i class="fa-solid fa-chart-line w-4"></i>
                    <span>Dashboard</span>
                </a>
                <a href="../pembelian/list.php" class="flex items-center space-x-2.5 px-3 py-2.5 rounded-lg hover:bg-[#1e293b] hover:text-white transition">
                    <i class="fa-solid fa-cart-shopping w-4"></i>
                    <span>Daftar Pembelian</span>
                </a>
                <a href="../approval/list.php" class="flex items-center space-x-2.5 px-3 py-2.5 rounded-lg hover:bg-[#1e293b] hover:text-white transition">
                    <i class="fa-solid fa-square-check w-4"></i>
                    <span>Approval Pembelian</span>
                </a>
                <a href="list.php" class="sidebar-active flex items-center space-x-2.5 px-3 py-2.5 rounded-lg transition">
                    <i class="fa-solid fa-tags w-4"></i>
                    <span>Harga Harian</span>
                </a>
                <a href="../vendor/list.php" class="flex items-center space-x-2.5 px-3 py-2.5 rounded-lg hover:bg-[#1e293b] hover:text-white transition">
                    <i class="fa-solid fa-building w-4"></i>
                    <span>Data Vendor</span>
                </a>
            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="flex-grow p-6 space-y-6">
            
            <!-- Flash Message Banner -->
            <?php if (!empty($flash_message)): ?>
                <div class="p-4 rounded-xl border flex items-center gap-2 <?php echo $flash_type === 'success' ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800'; ?>">
                    <i class="fa-solid <?php echo $flash_type === 'success' ? 'fa-circle-check' : 'fa-circle-exclamation'; ?> text-lg"></i>
                    <span class="font-bold text-xs"><?php echo htmlspecialchars($flash_message); ?></span>
                </div>
            <?php endif; ?>

            <!-- Title & Add Price Button -->
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-2">
                    <i class="fa-solid fa-tags text-xl text-[#334155]"></i>
                    <h2 class="text-xl font-black text-gray-800">Harga Harian (Notaring / Kering)</h2>
                </div>
                <button onclick="openPriceModal('add')" class="bg-green-600 hover:bg-green-700 text-white font-bold px-4 py-2 rounded-lg text-xs shadow flex items-center gap-1 transition">
                    <i class="fa-solid fa-plus-circle"></i> + Tetapkan / Update Harga
                </button>
            </div>
            
            <p class="text-xs text-gray-500 leading-none -mt-4">Harga ini dipakai sistem untuk menghitung DRC setiap pembelian: DRC = Harga Basah &divide; Harga Harian (Notaring) &times; 100%.</p>

            <!-- Current Price Big Display Card -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 flex flex-col justify-center">
                <p class="text-[10px] font-bold text-green-700 uppercase tracking-wider">Harga Hari Ini (<?php echo date('d.m.Y'); ?>)</p>
                <h1 class="text-3xl font-black text-gray-800 mt-1"><?php echo $today_price_formatted; ?> <span class="text-base font-normal text-gray-400">/ KG</span></h1>
                <p class="text-[10px] text-gray-400 mt-2">Ditetapkan oleh <?php echo htmlspecialchars($today_setter); ?> &bull; <?php echo $today_time; ?></p>
            </div>

            <!-- Table Card -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="p-4 bg-gray-50 border-b border-gray-200 font-extrabold text-xs text-gray-800">
                    Riwayat Harga Harian
                </div>
                
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 text-left">
                        <thead class="bg-gray-100 text-[10px] font-bold text-gray-500 uppercase tracking-wider">
                            <tr>
                                <th class="px-4 py-3">Tanggal</th>
                                <th class="px-4 py-3">Daerah</th>
                                <th class="px-4 py-3">Harga / KG</th>
                                <th class="px-4 py-3">Catatan</th>
                                <th class="px-4 py-3">Ditetapkan Oleh</th>
                                <th class="px-4 py-3">Terakhir Diubah</th>
                                <th class="px-4 py-3 text-right w-24">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100 text-xs">
                            <?php foreach ($prices as $p): ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-4 py-3.5 font-semibold text-gray-800"><?php echo date('d.m.Y', strtotime($p['tanggal'])); ?></td>
                                <td class="px-4 py-3.5 font-bold text-gray-900"><?php echo htmlspecialchars($p['daerah']); ?></td>
                                <td class="px-4 py-3.5 font-extrabold text-primary-800">Rp <?php echo number_format($p['harga_kg'], 0, ',', '.'); ?></td>
                                <td class="px-4 py-3.5 text-gray-500"><?php echo htmlspecialchars($p['catatan']); ?></td>
                                <td class="px-4 py-3.5 text-gray-600 font-semibold"><?php echo htmlspecialchars($p['ditetapkan_oleh']); ?></td>
                                <td class="px-4 py-3.5 text-gray-400"><?php echo date('d.m.Y H:i', strtotime($p['terakhir_diubah'])); ?></td>
                                <td class="px-4 py-3.5 text-right whitespace-nowrap space-x-1">
                                    <!-- Edit Button -->
                                    <button onclick='openPriceModal("edit", <?php echo json_encode($p); ?>)' 
                                            class="text-blue-600 hover:bg-blue-50 border border-blue-200 p-1.5 rounded transition inline-flex items-center justify-center">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </button>
                                    
                                    <!-- NEW DELETE BUTTON (HAPUS - FITUR BARU!) -->
                                    <a href="list.php?delete_id=<?php echo $p['id']; ?>" 
                                       onclick="return confirm('Apakah Anda yakin ingin menghapus riwayat harga harian untuk <?php echo htmlspecialchars($p['daerah']); ?> sebesar Rp <?php echo number_format($p['harga_kg'],0,',','.'); ?>?')" 
                                       class="text-red-600 hover:bg-red-50 border border-red-200 p-1.5 rounded transition inline-flex items-center justify-center">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </main>
    </div>

    <!-- Modal Dialog Tambah & Edit Harga (Sleek Modal) -->
    <div id="priceModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center hidden">
        <div class="bg-white rounded-2xl max-w-sm w-full mx-4 shadow-2xl overflow-hidden transition-all transform scale-95 opacity-0 duration-300" id="modalContainer">
            
            <div class="bg-[#1e293b] text-white px-5 py-3.5 flex justify-between items-center">
                <h3 class="font-extrabold text-sm" id="modalTitle">Tetapkan Harga Harian</h3>
                <button onclick="closePriceModal()" class="text-white hover:text-gray-200 transition">
                    <i class="fa-solid fa-xmark text-base"></i>
                </button>
            </div>
            
            <form id="priceForm" action="list.php" method="POST" class="p-5 space-y-4">
                <input type="hidden" name="action" id="form_action" value="add">
                <input type="hidden" name="id" id="edit_price_id">
                
                <div>
                    <label class="block text-[10px] font-bold text-gray-500 uppercase mb-1">Tanggal</label>
                    <input type="date" name="tanggal" id="form_date" required
                           class="w-full px-3 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 outline-none text-xs">
                </div>

                <div>
                    <label class="block text-[10px] font-bold text-gray-500 uppercase mb-1">Daerah / Wilayah *</label>
                    <input type="text" name="daerah" id="form_daerah" required placeholder="Contoh: Aceh Barat, Pabrik, dll."
                           class="w-full px-3 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 outline-none text-xs font-bold">
                </div>

                <div>
                    <label class="block text-[10px] font-bold text-gray-500 uppercase mb-1">Harga per Kg (Rp) *</label>
                    <input type="number" name="harga_kg" id="form_harga" required min="1" placeholder="35000"
                           class="w-full px-3 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 outline-none text-xs font-bold text-right text-green-700">
                </div>

                <div>
                    <label class="block text-[10px] font-bold text-gray-500 uppercase mb-1">Catatan</label>
                    <textarea name="catatan" id="form_catatan" rows="2" placeholder="Catatan tambahan..."
                              class="w-full px-3 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 outline-none text-xs text-gray-600"></textarea>
                </div>

                <div class="flex justify-end space-x-2 pt-2 border-t border-gray-100 font-bold">
                    <button type="button" onclick="closePriceModal()" class="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-lg transition">
                        Batal
                    </button>
                    <button type="submit" class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-xs rounded-lg shadow-sm transition">
                        Simpan Harga
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const priceModal = document.getElementById('priceModal');
        const modalContainer = document.getElementById('modalContainer');
        const priceForm = document.getElementById('priceForm');
        const modalTitle = document.getElementById('modalTitle');
        const formAction = document.getElementById('form_action');
        const editPriceId = document.getElementById('edit_price_id');
        const formDate = document.getElementById('form_date');
        const formDaerah = document.getElementById('form_daerah');
        const formHarga = document.getElementById('form_harga');
        const formCatatan = document.getElementById('form_catatan');

        function openPriceModal(action, data = null) {
            if (action === 'add') {
                modalTitle.textContent = "Tetapkan Harga Harian Baru";
                formAction.value = "add";
                editPriceId.value = "";
                formDate.value = new Date().toISOString().split('T')[0];
                formDaerah.value = "";
                formHarga.value = "";
                formCatatan.value = "";
            } else {
                modalTitle.textContent = "Ubah Riwayat Harga Harian";
                formAction.value = "edit";
                editPriceId.value = data.id;
                formDate.value = data.tanggal;
                formDaerah.value = data.daerah;
                formHarga.value = data.harga_kg;
                formCatatan.value = data.catatan;
            }
            
            priceModal.classList.remove('hidden');
            setTimeout(() => {
                modalContainer.classList.replace('scale-95', 'scale-100');
                modalContainer.classList.replace('opacity-0', 'opacity-100');
            }, 10);
        }

        function closePriceModal() {
            modalContainer.classList.replace('scale-100', 'scale-95');
            modalContainer.classList.replace('opacity-100', 'opacity-0');
            setTimeout(() => {
                priceModal.classList.add('hidden');
            }, 150);
        }
    </script>
</body>
</html>
