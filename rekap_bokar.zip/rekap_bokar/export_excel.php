<?php
// export_excel.php - Ekspor Rekapitulasi Bokar ke Excel (Split Grade & Dual Basket Weights)
require_once 'config.php';
require_login();

// Ambil parameter filter dari URL (GET)
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$supplier = $_GET['supplier'] ?? '';
$origin = $_GET['origin'] ?? '';
$grade_filter = $_GET['grade_filter'] ?? '';

// Bangun query secara dinamis
$query = "SELECT e.*, u.fullname as creator_name 
          FROM bokar_entries e 
          JOIN users u ON e.created_by = u.id 
          WHERE 1=1";
$params = [];

if (!empty($start_date)) {
    $query .= " AND DATE(e.created_at) >= DATE(?)";
    $params[] = $start_date;
}
if (!empty($end_date)) {
    $query .= " AND DATE(e.created_at) <= DATE(?)";
    $params[] = $end_date;
}
if (!empty($supplier)) {
    $query .= " AND e.supplier_name LIKE ?";
    $params[] = "%$supplier%";
}
if (!empty($origin)) {
    $query .= " AND e.origin LIKE ?";
    $params[] = "%$origin%";
}
if ($grade_filter === 'Grade A') {
    $query .= " AND e.grade_a_weight > 0";
} elseif ($grade_filter === 'Grade B') {
    $query .= " AND e.grade_b_weight > 0";
} elseif ($grade_filter === 'Grade C') {
    $query .= " AND e.grade_c_weight > 0";
}

$query .= " ORDER BY e.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$entries = $stmt->fetchAll();

// Set header download Excel
$filename = "rekap_bokar_" . date('Ymd_His') . ".xls";
header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=$filename");
header("Pragma: no-cache");
header("Expires: 0");

// Inisialisasi total
$total_gross = 0.0;
$total_basket = 0.0;
$total_net = 0.0;
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office" 
      xmlns:x="urn:schemas-microsoft-com:office:excel" 
      xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style>
    /* Desain CSS untuk Excel */
    table {
        border-collapse: collapse;
        font-family: 'Segoe UI', Arial, sans-serif;
    }
    th {
        background-color: #166534; /* Green matching primary-800 */
        color: #ffffff;
        font-weight: bold;
        text-align: center;
        border: 1px solid #999999;
        font-size: 10pt;
        padding: 8px;
    }
    td {
        border: 1px solid #cccccc;
        font-size: 9.5pt;
        padding: 6px;
    }
    .num-cell {
        text-align: right;
        mso-number-format: "#,##0.0"; /* Format angka desimal khas Excel */
    }
    .num-cell-green {
        text-align: right;
        mso-number-format: "#,##0.0";
        background-color: #f0fdf4;
        font-weight: bold;
    }
    .text-center {
        text-align: center;
    }
    .text-left {
        text-align: left;
    }
    .total-label {
        background-color: #dcfce7;
        font-weight: bold;
        text-align: center;
        border-top: 1px solid #000000;
        border-bottom: 2px double #000000;
        font-size: 11pt;
    }
    .total-num {
        background-color: #dcfce7;
        font-weight: bold;
        text-align: right;
        border-top: 1px solid #000000;
        border-bottom: 2px double #000000;
        mso-number-format: "#,##0.0";
        font-size: 11pt;
    }
    .total-num-green {
        background-color: #dcfce7;
        color: #166534;
        font-weight: bold;
        text-align: right;
        border-top: 1px solid #000000;
        border-bottom: 2px double #000000;
        mso-number-format: "#,##0.0";
        font-size: 11pt;
    }
    .total-dash {
        background-color: #dcfce7;
        font-weight: bold;
        text-align: center;
        border-top: 1px solid #000000;
        border-bottom: 2px double #000000;
    }
</style>
</head>
<body>
    <h2>LAPORAN REKAPITULASI BAHAN OLAHAN KARET (BOKAR)</h2>
    <p><b>PT Potensi Bumi Sakti (Arsari Group)</b></p>
    <p>Tanggal Ekspor: <?php echo date('d-m-Y H:i:s'); ?></p>
    <?php if (!empty($start_date) || !empty($end_date) || !empty($supplier) || !empty($origin) || !empty($grade_filter)): ?>
    <p><b>Filter Aktif:</b> 
        <?php
        $f_active = [];
        if (!empty($start_date)) $f_active[] = "Mulai: $start_date";
        if (!empty($end_date)) $f_active[] = "Sampai: $end_date";
        if (!empty($supplier)) $f_active[] = "Supplier: $supplier";
        if (!empty($origin)) $f_active[] = "Asal: $origin";
        if (!empty($grade_filter)) $f_active[] = "Filter: Memiliki $grade_filter";
        echo implode(" | ", $f_active);
        ?>
    </p>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>No. Slip</th>
                <th>Tanggal</th>
                <th>Nama Supplier</th>
                <th>Asal Bokar</th>
                <th>Berat Kotor (Gross) (Kg)</th>
                <th>Rincian [Gross/Tara] Per Wadah</th>
                <th>Total Berat Keranjang (Tara) (Kg)</th>
                <th>Berat Bersih Bokar (Netto) (Kg)</th>
                <th>Berat Grade A (Kg)</th>
                <th>Berat Grade B (Kg)</th>
                <th>Berat Grade C (Kg)</th>
                <th>Petugas Input</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $idx = 1; 
            foreach ($entries as $entry): 
                $gross_list = json_decode($entry['gross_weights'] ?? '[]', true) ?? [$entry['gross_weight']];
                $baskets_list = json_decode($entry['basket_weights'] ?? '[]', true) ?? [$entry['total_basket_weight']];
                
                $details_arr = [];
                for ($i = 0; $i < count($gross_list); $i++) {
                    $details_arr[] = "Kj " . ($i + 1) . " (" . $gross_list[$i] . "/" . $baskets_list[$i] . ")";
                }
                $baskets_str = implode(", ", $details_arr);
                
                $total_gross += $entry['gross_weight'];
                $total_basket += $entry['total_basket_weight'];
                $total_net += $entry['net_weight'];
            ?>
            <tr>
                <td class="text-center"><?php echo $idx++; ?></td>
                <td class="text-center"><b><?php echo htmlspecialchars($entry['slip_number']); ?></b></td>
                <td class="text-center"><?php echo $entry['created_at']; ?></td>
                <td class="text-left"><?php echo htmlspecialchars($entry['supplier_name']); ?></td>
                <td class="text-left"><?php echo htmlspecialchars($entry['origin']); ?></td>
                <td class="num-cell"><?php echo $entry['gross_weight']; ?></td>
                <td class="text-center"><?php echo $baskets_str; ?></td>
                <td class="num-cell" style="color: #dc2626;"><?php echo $entry['total_basket_weight']; ?></td>
                <td class="num-cell-green"><?php echo $entry['net_weight']; ?></td>
                <td class="num-cell" style="background-color: #f0fdf4; font-weight: 500; color: #16a34a;"><?php echo $entry['grade_a_weight']; ?></td>
                <td class="num-cell" style="background-color: #eff6ff; font-weight: 500; color: #2563eb;"><?php echo $entry['grade_b_weight']; ?></td>
                <td class="num-cell" style="background-color: #fef9c3; font-weight: 500; color: #ca8a04;"><?php echo $entry['grade_c_weight']; ?></td>
                <td class="text-left"><?php echo htmlspecialchars($entry['creator_name']); ?></td>
            </tr>
            <?php endforeach; ?>
            
            <!-- Grand Totals Row with Formulas -->
            <tr>
                <td colspan="5" class="total-label">TOTAL KESELURUHAN</td>
                <!-- Excel SUM Formulas representing the exact column range! -->
                <td class="total-num">=SUM(F5:F<?php echo $idx + 3; ?>)</td>
                <td class="total-dash">-</td>
                <td class="total-num" style="color: #dc2626;">=SUM(H5:H<?php echo $idx + 3; ?>)</td>
                <td class="total-num-green">=SUM(I5:I<?php echo $idx + 3; ?>)</td>
                <td class="total-num" style="color: #16a34a;">=SUM(J5:J<?php echo $idx + 3; ?>)</td>
                <td class="total-num" style="color: #2563eb;">=SUM(K5:K<?php echo $idx + 3; ?>)</td>
                <td class="total-num" style="color: #ca8a04;">=SUM(L5:L<?php echo $idx + 3; ?>)</td>
                <td class="total-dash">-</td>
            </tr>
        </tbody>
    </table>
</body>
</html>
