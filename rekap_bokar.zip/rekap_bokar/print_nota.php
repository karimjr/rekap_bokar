<?php
// print_nota.php - Cetak Nota Timbangan Bokar Individual (MySQL - Multi-Kelompok Grouped Receipt)
require_once 'config.php';
require_login();

// Ambil list ID yang dipilih
$ids_str = $_GET['ids'] ?? '';
if (empty($ids_str)) {
    die("<div style='font-family: sans-serif; text-align: center; margin-top: 50px;'>
            <h3 style='color: red;'>Gagal Mencetak!</h3>
            <p>Tidak ada data slip yang dipilih untuk dicetak. Silakan tandai kotak centang pada daftar tabel terlebih dahulu.</p>
            <a href='index.php' style='text-decoration: none; color: white; background: #16a34a; padding: 10px 20px; border-radius: 5px; font-weight: bold;'>Kembali ke Dashboard</a>
         </div>");
}

$ids = array_filter(array_map('intval', explode(',', $ids_str)));
if (empty($ids)) {
    die("ID slip tidak valid.");
}

// Ambil data dari database menggunakan parameter binding yang aman
$placeholders = implode(',', array_fill(0, count($ids), '?'));
$query = "SELECT e.*, u.fullname as creator_name 
          FROM bokar_entries e 
          JOIN users u ON e.created_by = u.id 
          WHERE e.id IN ($placeholders)
          ORDER BY e.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($ids);
$entries = $stmt->fetchAll();

foreach ($entries as &$entry) {
    $entry['gross_list'] = json_decode($entry['gross_weights'] ?? '[]', true) ?? [$entry['gross_weight']];
    $entry['baskets_list'] = json_decode($entry['basket_weights'] ?? '[]', true) ?? [$entry['total_basket_weight']];
    $entry['grades_list'] = json_decode($entry['basket_grades'] ?? '[]', true) ?? [];
    $entry['kelompoks_list'] = json_decode($entry['basket_kelompoks'] ?? '[]', true) ?? [];
    
    if (empty($entry['grades_list'])) {
        $entry['grades_list'] = array_fill(0, count($entry['gross_list']), 'Grade A');
    }
    if (empty($entry['kelompoks_list'])) {
        $entry['kelompoks_list'] = array_fill(0, count($entry['gross_list']), 'Kelompok 1');
    }
}
unset($entry);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Nota Timbangan Bokar</title>
    <!-- Tailwind CSS CDN -->
    <link rel="stylesheet" href="assets/css/tailwind.css">
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <style>
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                background: white;
                color: black;
            }
            .nota-page {
                page-break-after: always;
                border: none !important;
                box-shadow: none !important;
                margin-bottom: 0 !important;
                padding: 10px !important;
            }
            .nota-page:last-child {
                page-break-after: avoid;
            }
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen py-6 px-4">

    <!-- Action Bar (Tersembunyi saat dicetak) -->
    <div class="max-w-xl mx-auto mb-6 no-print flex justify-between items-center bg-white p-4 rounded-xl shadow border border-gray-200">
        <a href="index.php" class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-2 rounded-lg text-sm font-semibold transition flex items-center gap-1">
            <i class="fa-solid fa-arrow-left"></i> Kembali
        </a>
        <span class="text-xs text-gray-500 font-semibold font-mono">Total: <?php echo count($entries); ?> Nota</span>
        <button onclick="window.print()" class="bg-green-600 hover:bg-green-700 text-white font-bold px-4 py-2 rounded-lg text-sm shadow transition flex items-center gap-1.5">
            <i class="fa-solid fa-print"></i> Cetak Semua Nota
        </button>
    </div>

    <!-- Loop Render Nota -->
    <?php foreach ($entries as $entry): 
        // Pengelompokan keranjang timbangan berdasarkan "Kelompok Timbang" (kelompok/batch)
        $baskets_by_kelompok = [];
        $gross_list = $entry['gross_list'];
        $baskets_list = $entry['baskets_list'];
        $grades_list = $entry['grades_list'];
        $kelompoks_list = $entry['kelompoks_list'];

        for ($i = 0; $i < count($gross_list); $i++) {
            $g = $gross_list[$i] ?? 0;
            $t = $baskets_list[$i] ?? 0;
            $gr = $grades_list[$i] ?? 'Grade A';
            $kelompok = $kelompoks_list[$i] ?? 'Kelompok 1';
            
            if (!isset($baskets_by_kelompok[$kelompok])) {
                $baskets_by_kelompok[$kelompok] = [];
            }
            
            $baskets_by_kelompok[$kelompok][] = [
                'index' => $i + 1,
                'gross' => $g,
                'tara' => $t,
                'net' => $g - $t,
                'grade' => $gr
            ];
        }
    ?>
    <div class="nota-page max-w-xl mx-auto bg-white border-2 border-dashed border-gray-300 p-6 rounded-xl shadow-sm mb-6 relative">
        
        <!-- Watermark -->
        <div class="absolute right-6 top-16 opacity-10 select-none no-print">
            <i class="fa-solid fa-tree text-9xl text-green-800"></i>
        </div>

        <!-- Kop Nota -->
        <div class="text-center border-b border-gray-200 pb-3 mb-4">
            <h2 class="text-base font-black text-gray-900 tracking-tight flex justify-center items-center gap-1.5 uppercase">
                <i class="fa-solid fa-tree text-green-700"></i> PT Potensi Bumi Sakti (Arsari Group)
            </h2>
            <p class="text-[9px] text-gray-500 leading-normal mt-1">Jl. Tgk Ibrahim No.Desa, Glee Siblah, Woyla, West Aceh Regency, Aceh 23654</p>
            <h3 class="text-sm font-black text-gray-800 uppercase tracking-widest mt-2 border-t border-gray-100 pt-1.5">
                NOTA TIMBANGAN RESMI
            </h3>
        </div>

        <!-- Detail Slip metadata (1 SUPPIER CONSOLIDATED) -->
        <div class="grid grid-cols-2 gap-y-1.5 text-xs text-gray-600 border-b border-gray-100 pb-3 mb-3">
            <div>
                <span class="text-gray-400 block text-[10px] uppercase">No. Slip</span>
                <span class="font-mono font-black text-primary-800 text-sm"><?php echo htmlspecialchars($entry['slip_number']); ?></span>
            </div>
            <div class="text-right">
                <span class="text-gray-400 block text-[10px] uppercase">Tanggal Timbang</span>
                <span class="font-semibold text-gray-800"><?php echo substr($entry['created_at'], 0, 16); ?></span>
            </div>
            <div>
                <span class="text-gray-400 block text-[10px] uppercase">Nama Supplier</span>
                <span class="font-bold text-gray-800 text-sm"><?php echo htmlspecialchars($entry['supplier_name']); ?></span>
            </div>
            <div class="text-right">
                <span class="text-gray-400 block text-[10px] uppercase">Asal Daerah</span>
                <span class="font-semibold text-gray-800"><?php echo htmlspecialchars($entry['origin']); ?></span>
            </div>
            <div>
                <span class="text-gray-400 block text-[10px] uppercase">No. Kendaraan</span>
                <span class="font-bold text-gray-800 font-mono uppercase"><?php echo htmlspecialchars($entry['vehicle_number'] ?? '-'); ?></span>
            </div>
            <div class="text-right">
                <!-- Spacer -->
            </div>
        </div>

        <!-- Rincian Hasil Timbangan Berkelompok berdasarkan "Kelompok Timbang" -->
        <div class="space-y-3.5 text-xs border-b border-gray-100 pb-3.5 mb-3.5">
            <p class="text-[10px] font-bold text-gray-400 uppercase tracking-wider"><i class="fa-solid fa-scale-balanced text-primary-600"></i> Rincian Timbangan per Kelompok Timbang (Kg)</p>
            
            <?php foreach ($baskets_by_kelompok as $kelompok_name => $items): 
                $sub_total_net = 0;
            ?>
                <div class="bg-gray-50 p-3 rounded-lg border border-gray-200 space-y-2">
                    <span class="text-[10px] font-black text-gray-800 uppercase block border-b border-gray-200 pb-1 mb-1 flex items-center gap-1">
                        <i class="fa-solid fa-boxes-stacked text-primary-600"></i>
                        <?php echo htmlspecialchars($kelompok_name); ?>
                    </span>
                    <div class="space-y-1">
                        <?php foreach ($items as $item): 
                            $sub_total_net += $item['net'];
                            $gr_letter = substr($item['grade'], -1);
                            $badge_color = $item['grade'] === 'Grade A' ? 'text-green-700 bg-green-50 border-green-100' : ($item['grade'] === 'Grade B' ? 'text-blue-700 bg-blue-50 border-blue-100' : 'text-yellow-700 bg-yellow-50 border-yellow-100');
                        ?>
                        <div class="flex justify-between items-center text-[11px] py-0.5 border-b border-gray-100 border-dashed last:border-none">
                            <span class="text-gray-600">Timbangan #<?php echo $item['index']; ?> 
                                <span class="text-[9px] px-1.5 py-0.2 rounded font-bold border <?php echo $badge_color; ?>">Grade <?php echo $gr_letter; ?></span> 
                                <span class="text-[9px] text-gray-400 font-mono">(Gross: <?php echo number_format($item['gross'], 1); ?> | Tara: <?php echo number_format($item['tara'], 1); ?>)</span>
                            </span>
                            <span class="font-bold text-gray-800"><?php echo number_format($item['net'], 1); ?> Kg</span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="flex justify-between items-center text-[10px] border-t border-gray-200 pt-1 mt-1 font-black text-primary-800">
                        <span>Subtotal Bersih <?php echo htmlspecialchars($kelompok_name); ?>:</span>
                        <span><?php echo number_format($sub_total_net, 1); ?> Kg</span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Klasifikasi Pembagian Kualitas (Grade) - CARDS -->
        <div class="space-y-1.5 text-xs mb-3.5">
            <p class="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5"><i class="fa-solid fa-layer-group text-primary-600"></i> Distribusi Berat per Grade</p>
            
            <div class="grid grid-cols-3 gap-2 text-center text-[11px] font-bold">
                <div class="bg-green-50 border border-green-200 p-2 rounded-lg">
                    <span class="text-[9px] text-green-700 block uppercase font-black">Grade A</span>
                    <span class="text-green-800 text-xs"><?php echo number_format($entry['grade_a_weight'], 1); ?> Kg</span>
                </div>
                <div class="bg-blue-50 border border-blue-200 p-2 rounded-lg">
                    <span class="text-[9px] text-blue-700 block uppercase font-black">Grade B</span>
                    <span class="text-blue-800 text-xs"><?php echo number_format($entry['grade_b_weight'], 1); ?> Kg</span>
                </div>
                <div class="bg-yellow-50 border border-yellow-200 p-2 rounded-lg">
                    <span class="text-[9px] text-yellow-700 block uppercase font-black">Grade C</span>
                    <span class="text-yellow-800 text-xs"><?php echo number_format($entry['grade_c_weight'], 1); ?> Kg</span>
                </div>
            </div>
        </div>

        <!-- TOTAL BERAT BERSIH (NETTO) - TAMPILKAN DI BAWAH GRADE (SESUAI REVISI) -->
        <div class="flex justify-between items-center py-2.5 bg-green-800 text-white px-3.5 rounded-lg mb-4 shadow-sm border border-green-900">
            <span class="font-extrabold uppercase tracking-wider text-xs flex items-center gap-1.5">
                <i class="fa-solid fa-weight-scale"></i> TOTAL BERAT BERSIH (NETTO)
            </span>
            <span class="font-black text-lg"><?php echo number_format($entry['net_weight'], 1); ?> Kg</span>
        </div>

        <!-- Tanda Tangan Ganda -->
        <div class="grid grid-cols-2 text-center text-[10px] text-gray-500 mt-4 gap-4">
            <div>
                <p>Pihak Supplier,</p>
                <div class="h-12 flex items-end justify-center">
                    <span class="text-gray-300 italic text-[9px]">(Tanda Tangan)</span>
                </div>
                <p class="font-bold text-gray-800 uppercase mt-1 border-t border-gray-200 pt-1">
                    <?php echo htmlspecialchars($entry['supplier_name']); ?>
                </p>
            </div>
            <div>
                <p>Petugas Timbangan,</p>
                <div class="h-12 flex items-end justify-center">
                    <span class="text-gray-300 italic text-[9px]">(Tanda Tangan & Cap)</span>
                </div>
                <p class="font-bold text-gray-800 uppercase mt-1 border-t border-gray-200 pt-1">
                    <?php echo htmlspecialchars($entry['creator_name']); ?>
                </p>
            </div>
        </div>

        <!-- Catatan Footer -->
        <div class="text-center mt-6 text-[9px] text-gray-400 border-t border-gray-100 pt-3">
            <p>Terima kasih atas kerja samanya. Harap simpan nota ini sebagai bukti timbang resmi.</p>
            <p class="font-mono mt-0.5 font-bold">PT Potensi Bumi Sakti (Arsari Group)</p>
        </div>

    </div>
    <?php endforeach; ?>

</body>
</html>
