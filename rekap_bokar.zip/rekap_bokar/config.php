<?php
// config.php
// Konfigurasi Koneksi Database MySQL (PT Potensi Bumi Sakti - Arsari Group)

$db_host = '127.0.0.1';
$db_name = 'rekap_bokar';

try {
    // Koneksi menggunakan user resmi produksi: abdulkar_pbs / arsari-group
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    die("Koneksi ke Database gagal! Silakan impor file 'rekap_bokar.sql' di phpMyAdmin Anda dahulu.<br>Detail error: " . $e->getMessage());
}

// -------------------------------------------------------------------------
// 🛠️ MEKANISME PERBAIKAN DATABASE OTOMATIS SENYAP (100% BULLETPROOF & AMAN)
// -------------------------------------------------------------------------
// Script ini otomatis mendeteksi dan memperbaiki nama kolom database lokal Anda 
// di latar belakang tanpa Anda perlu mengedit database manual di phpMyAdmin!
try {
    // Cek apakah tabel bokar_entries sudah dibuat
    $table_check = $pdo->query("SHOW TABLES LIKE 'bokar_entries'");
    if ($table_check->fetch()) {
        // 1. Cek apakah kolom 'basket_kelompoks' sudah ada
        $column_check = $pdo->query("SHOW COLUMNS FROM `bokar_entries` LIKE 'basket_kelompoks'");
        if (!$column_check->fetch()) {
            
            // 2. Kolom belum ada! Cek apakah kolom lama 'basket_lots' masih ada untuk di-rename
            $old_lots_check = $pdo->query("SHOW COLUMNS FROM `bokar_entries` LIKE 'basket_lots'");
            if ($old_lots_check->fetch()) {
                $pdo->exec("ALTER TABLE `bokar_entries` CHANGE `basket_lots` `basket_kelompoks` TEXT NOT NULL");
            } else {
                
                // 3. Cek apakah kolom lama bernama 'basket_parties' masih ada untuk di-rename
                $old_parties_check = $pdo->query("SHOW COLUMNS FROM `bokar_entries` LIKE 'basket_parties'");
                if ($old_parties_check->fetch()) {
                    $pdo->exec("ALTER TABLE `bokar_entries` CHANGE `basket_parties` `basket_kelompoks` TEXT NOT NULL");
                } else {
                    
                    // 4. Jika tidak ada kolom lama sama sekali, buat baru secara senyap
                    $pdo->exec("ALTER TABLE `bokar_entries` ADD `basket_kelompoks` TEXT NOT NULL AFTER `basket_grades`");
                }
            }
        }
    }
} catch (PDOException $e_heal) {
    // Abaikan jika database masih kosong pertama kali
}

// Mulai session jika belum dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Fungsi helper flash message
function set_flash($type, $text) {
    $_SESSION['flash_message'] = ['type' => $type, 'text' => $text];
}

function display_flash() {
    if (isset($_SESSION['flash_message'])) {
        $msg = $_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        
        $bg_color = 'bg-blue-50 border-blue-200 text-blue-800';
        $icon = 'fa-circle-info';
        
        if ($msg['type'] === 'success') {
            $bg_color = 'bg-green-50 border-green-200 text-green-800';
            $icon = 'fa-circle-check';
        } elseif ($msg['type'] === 'error') {
            $bg_color = 'bg-red-50 border-red-200 text-red-800';
            $icon = 'fa-circle-exclamation';
        }
        
        echo '
        <div class="mb-4 p-4 rounded-xl border flex items-start space-x-3 ' . $bg_color . ' no-print">
            <i class="fa-solid ' . $icon . ' text-lg mt-0.5"></i>
            <div class="flex-1 text-sm font-medium">' . htmlspecialchars($msg['text']) . '</div>
        </div>';
    }
}

// Helper untuk mengecek login
function require_login() {
    if (!isset($_SESSION['user_id'])) {
        set_flash('error', 'Silakan login terlebih dahulu untuk mengakses sistem.');
        header("Location: login.php");
        exit;
    }
}

// Helper untuk mengecek peran admin
function require_admin() {
    require_login();
    if ($_SESSION['role'] !== 'admin') {
        set_flash('error', 'Anda tidak memiliki hak akses (Admin Only) untuk halaman tersebut.');
        header("Location: index.php");
        exit;
    }
}

// --------------------------------------------------------
// HELPER NO. SLIP OTOMATIS & BERURUTAN
// --------------------------------------------------------
function get_next_slip_number($pdo) {
    try {
        // Ambil prefix
        $stmt = $pdo->prepare("SELECT key_value FROM system_settings WHERE key_name = 'slip_prefix'");
        $stmt->execute();
        $prefix = $stmt->fetchColumn();
        if ($prefix === false) $prefix = 'SLIP-';
        
        // Ambil counter
        $stmt = $pdo->prepare("SELECT key_value FROM system_settings WHERE key_name = 'slip_counter'");
        $stmt->execute();
        $counter = $stmt->fetchColumn();
        if ($counter === false) $counter = 1;
        $counter = (int)$counter;
        
        // Format: SLIP-0005, SLIP-1028 (padding minimal 4 digit)
        $formatted_counter = str_pad($counter, 4, '0', STR_PAD_LEFT);
        return $prefix . $formatted_counter;
    } catch (PDOException $e) {
        return 'SLIP-ERR';
    }
}

function increment_slip_counter($pdo) {
    try {
        $stmt = $pdo->prepare("UPDATE system_settings SET key_value = CAST(key_value AS UNSIGNED) + 1 WHERE key_name = 'slip_counter'");
        $stmt->execute();
    } catch (PDOException $e) {
        // Abaikan atau log
    }
}
?>
