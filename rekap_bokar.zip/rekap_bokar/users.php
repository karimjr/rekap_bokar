<?php
// users.php - Manajemen Pengguna & Pengaturan Sistem (Admin Only)
require_once 'config.php';
require_admin();

// Handler POST Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // 1. ADD USER
    if ($action === 'add') {
        $username = trim(strtolower($_POST['username']));
        $fullname = trim($_POST['fullname']);
        $password = $_POST['password'];
        $role = $_POST['role'];
        
        if (!empty($username) && !empty($fullname) && !empty($password) && !empty($role)) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetchColumn() > 0) {
                set_flash('error', 'Username sudah terdaftar! Gunakan username lain.');
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (username, password, fullname, role) VALUES (?, ?, ?, ?)");
                $stmt->execute([$username, $hashed_password, $fullname, $role]);
                set_flash('success', "Pengguna $fullname ($username) berhasil ditambahkan!");
            }
        } else {
            set_flash('error', 'Semua kolom harus diisi.');
        }
        header("Location: users.php");
        exit;
    }
    
    // 2. EDIT USER
    if ($action === 'edit') {
        $user_id = (int)$_POST['user_id'];
        $username = trim(strtolower($_POST['username']));
        $fullname = trim($_POST['fullname']);
        $password = $_POST['password'];
        $role = $_POST['role'];
        
        if (!empty($user_id) && !empty($username) && !empty($fullname) && !empty($role)) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND id != ?");
            $stmt->execute([$username, $user_id]);
            if ($stmt->fetchColumn() > 0) {
                set_flash('error', 'Username sudah terdaftar! Gunakan username lain.');
            } else {
                if (!empty($password)) {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE users SET username = ?, fullname = ?, password = ?, role = ? WHERE id = ?");
                    $stmt->execute([$username, $fullname, $hashed_password, $role, $user_id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE users SET username = ?, fullname = ?, role = ? WHERE id = ?");
                    $stmt->execute([$username, $fullname, $role, $user_id]);
                }
                set_flash('success', "Data pengguna $fullname berhasil diperbarui!");
            }
        } else {
            set_flash('error', 'Semua kolom harus diisi.');
        }
        header("Location: users.php");
        exit;
    }

    // 3. UPDATE SYSTEM SETTINGS (Slip Code Customizer)
    if ($action === 'update_settings') {
        $slip_prefix = trim(strtoupper($_POST['slip_prefix']));
        $slip_counter = (int)$_POST['slip_counter'];
        
        if ($slip_counter < 1) {
            $slip_counter = 1;
        }
        
        try {
            $stmt = $pdo->prepare("UPDATE system_settings SET key_value = ? WHERE key_name = 'slip_prefix'");
            $stmt->execute([$slip_prefix]);
            
            $stmt = $pdo->prepare("UPDATE system_settings SET key_value = ? WHERE key_name = 'slip_counter'");
            $stmt->execute([$slip_counter]);
            
            set_flash('success', "Pengaturan No. Slip berhasil disimpan! Slip berikutnya: " . get_next_slip_number($pdo));
        } catch (PDOException $e) {
            set_flash('error', "Gagal memperbarui pengaturan: " . $e->getMessage());
        }
        header("Location: users.php");
        exit;
    }
}

// Handler GET Actions
if (isset($_GET['delete'])) {
    $delete_id = (int)$_GET['delete'];
    
    if ($delete_id === (int)$_SESSION['user_id']) {
        set_flash('error', 'Anda tidak dapat menghapus akun Anda sendiri yang sedang aktif.');
    } else {
        $stmt = $pdo->prepare("SELECT fullname FROM users WHERE id = ?");
        $stmt->execute([$delete_id]);
        $fullname = $stmt->fetchColumn();
        
        if ($fullname) {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$delete_id]);
            set_flash('success', "Pengguna $fullname berhasil dihapus!");
        } else {
            set_flash('error', 'Pengguna tidak ditemukan.');
        }
    }
    header("Location: users.php");
    exit;
}

// Handler Reset Slip
if (isset($_GET['reset_slip'])) {
    try {
        $stmt = $pdo->prepare("UPDATE system_settings SET key_value = 'SLIP-' WHERE key_name = 'slip_prefix'");
        $stmt->execute();
        
        $stmt = $pdo->prepare("UPDATE system_settings SET key_value = '1' WHERE key_name = 'slip_counter'");
        $stmt->execute();
        
        set_flash('success', "Sistem penomoran No. Slip berhasil direset ke awal (SLIP-0001)!");
    } catch (PDOException $e) {
        set_flash('error', "Gagal mereset No. Slip: " . $e->getMessage());
    }
    header("Location: users.php");
    exit;
}

// Ambil semua daftar user
$stmt = $pdo->query("SELECT id, username, fullname, role, created_at FROM users ORDER BY created_at DESC");
$users = $stmt->fetchAll();

// Ambil data pengaturan No Slip terkini
$stmt = $pdo->prepare("SELECT key_value FROM system_settings WHERE key_name = 'slip_prefix'");
$stmt->execute();
$current_prefix = $stmt->fetchColumn() ?: 'SLIP-';

$stmt = $pdo->prepare("SELECT key_value FROM system_settings WHERE key_name = 'slip_counter'");
$stmt->execute();
$current_counter = $stmt->fetchColumn() ?: 1;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pengguna & Sistem - Rekapitulasi Bokar</title>
    <!-- Tailwind CSS CDN -->
    <link rel="stylesheet" href="assets/css/tailwind.css">
    <!-- FontAwesome icons -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
</head>
<body class="bg-gray-50 text-gray-800 flex flex-col min-h-screen font-sans">

    <!-- Header / Navbar -->
    <header class="bg-primary-800 text-white shadow-md no-print py-2">
        <div class="container mx-auto px-4 py-1 flex justify-between items-center">
            <a href="index.php" class="flex items-center space-x-3">
                <div class="bg-white p-2 rounded-full text-primary-800">
                    <i class="fa-solid fa-tree text-xl"></i>
                </div>
                <div>
                    <h1 class="text-xl font-bold tracking-tight">Rekapitulasi Bokar</h1>
                    <p class="text-xs text-primary-200">PT Potensi Bumi Sakti (Arsari Group)</p>
                </div>
            </a>
            
            <div class="flex items-center space-x-4">
                <span class="text-sm bg-primary-700 px-3 py-1.5 rounded-lg flex items-center space-x-2">
                    <i class="fa-solid fa-user-circle"></i>
                    <span><strong><?php echo htmlspecialchars($_SESSION['fullname']); ?></strong> (<?php echo ucfirst($_SESSION['role']); ?>)</span>
                </span>
                <a href="logout.php" class="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded-lg text-sm font-semibold transition flex items-center space-x-1">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    <span class="hidden sm:inline">Logout</span>
                </a>
            </div>
        </div>
    </header>

    <!-- Main Navigation & Workspace Layout -->
    <div class="flex-grow flex flex-col md:flex-row container mx-auto px-4 py-6 gap-6">
        
        <!-- Sidebar Navigation -->
        <aside class="w-full md:w-52 flex-shrink-0 no-print">
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4 space-y-2">
                <p class="text-xs font-semibold text-gray-400 uppercase tracking-wider px-3 mb-2">Main Menu</p>
                
                <a href="index.php" class="flex items-center space-x-3 px-3 py-2 rounded-lg text-xs font-semibold text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition">
                    <i class="fa-solid fa-chart-line w-4"></i>
                    <span>Dashboard</span>
                </a>
                
                <a href="users.php" class="flex items-center space-x-3 px-3 py-2 rounded-lg text-xs font-semibold bg-primary-50 text-primary-700 border-l-4 border-primary-600 transition">
                    <i class="fa-solid fa-users-gear w-4"></i>
                    <span>Kelola Pengguna</span>
                </a>
                
                <hr class="my-4 border-gray-100">
                
                <div class="p-3 bg-green-50 rounded-lg text-xs text-primary-800 leading-relaxed">
                    <p class="font-bold mb-1"><i class="fa-solid fa-circle-info"></i> Petunjuk Admin</p>
                    <p>Atur akun operator timbangan dan ubah format No. Slip yang akan digenerate otomatis oleh sistem.</p>
                </div>
            </div>
        </aside>

        <!-- Content Area -->
        <main class="flex-grow space-y-6">
            <!-- Flash Messages -->
            <?php display_flash(); ?>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                <!-- KOLOM KIRI: Daftar Pengguna (Spans 2 cols) -->
                <div class="lg:col-span-2 space-y-6">
                    <div class="flex justify-between items-center">
                        <div>
                            <h2 class="text-2xl font-bold text-gray-900">Kelola Pengguna</h2>
                            <p class="text-sm text-gray-500">Atur akun operator timbangan lapangan.</p>
                        </div>
                        <button onclick="openAddModal()" class="bg-primary-600 hover:bg-primary-700 text-white font-semibold px-4 py-2 rounded-lg text-sm shadow flex items-center gap-2 transition">
                            <i class="fa-solid fa-user-plus"></i> Tambah Pengguna
                        </button>
                    </div>

                    <!-- Users Table Card -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50 text-xs font-bold text-gray-500 uppercase">
                                    <tr>
                                        <th class="px-4 py-3 text-left">No</th>
                                        <th class="px-4 py-3 text-left">Nama</th>
                                        <th class="px-4 py-3 text-left">Username</th>
                                        <th class="px-4 py-3 text-left">Role</th>
                                        <th class="px-4 py-3 text-right">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-100">
                                    <?php $idx = 1; foreach ($users as $user): ?>
                                    <tr class="hover:bg-gray-50 transition text-sm">
                                        <td class="px-4 py-3 text-gray-500"><?php echo $idx++; ?></td>
                                        <td class="px-4 py-3 font-semibold text-gray-900"><?php echo htmlspecialchars($user['fullname']); ?></td>
                                        <td class="px-4 py-3 font-mono text-gray-600"><?php echo htmlspecialchars($user['username']); ?></td>
                                        <td class="px-4 py-3">
                                            <?php if ($user['role'] === 'admin'): ?>
                                            <span class="bg-purple-50 text-purple-700 border border-purple-100 px-2.5 py-0.5 rounded-full text-xs font-semibold">Admin</span>
                                            <?php else: ?>
                                            <span class="bg-blue-50 text-blue-700 border border-blue-100 px-2.5 py-0.5 rounded-full text-xs font-semibold">Petugas</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-4 py-3 text-right space-x-1 whitespace-nowrap">
                                            <button onclick='openEditModal(<?php echo json_encode($user); ?>)' class="text-primary-600 hover:text-primary-900 bg-primary-50 hover:bg-primary-100 px-2 py-1 rounded transition text-xs">
                                                Edit
                                            </button>
                                            <?php if ((int)$user['id'] !== (int)$_SESSION['user_id']): ?>
                                            <a href="users.php?delete=<?php echo $user['id']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus user <?php echo htmlspecialchars($user['fullname']); ?>?')" class="text-red-600 hover:text-red-950 bg-red-50 hover:bg-red-100 px-2 py-1 rounded transition text-xs">
                                                Hapus
                                            </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- KOLOM KANAN: Pengaturan No. Slip (Spans 1 col) -->
                <div class="space-y-6">
                    
                    <!-- KONFIGURASI NO. SLIP -->
                    <div>
                        <h2 class="text-lg font-bold text-gray-900">Sistem & Timbangan</h2>
                        <p class="text-xs text-gray-500">Atur penomoran slip otomatis.</p>
                    </div>

                    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5 space-y-4">
                        <div class="bg-primary-50 p-4 rounded-xl border border-primary-100 text-center">
                            <p class="text-xs text-primary-700 font-bold uppercase tracking-wider leading-none">No. Slip Berikutnya</p>
                            <h2 class="text-2xl font-black text-primary-800 font-mono mt-1" id="slip-preview">
                                <?php echo get_next_slip_number($pdo); ?>
                            </h2>
                            <p class="text-[10px] text-primary-600 mt-1 leading-none">Otomatis digenerate berurutan</p>
                        </div>

                        <!-- Form Settings -->
                        <form action="users.php" method="POST" class="space-y-4">
                            <input type="hidden" name="action" value="update_settings">
                            
                            <div>
                                <label class="block text-xs font-semibold text-gray-700 mb-1">Prefix Kode Slip</label>
                                <input type="text" name="slip_prefix" id="set_prefix" required value="<?php echo htmlspecialchars($current_prefix); ?>"
                                       class="w-full px-3 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none text-sm font-mono uppercase"
                                       oninput="updateSlipPreview()">
                            </div>

                            <div>
                                <label class="block text-xs font-semibold text-gray-700 mb-1">Dimulai dari Urutan (Counter)</label>
                                <input type="number" name="slip_counter" id="set_counter" required min="1" value="<?php echo $current_counter; ?>"
                                       class="w-full px-3 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none text-sm font-semibold"
                                       oninput="updateSlipPreview()">
                            </div>

                            <!-- Buttons -->
                            <div class="flex flex-col gap-2 pt-2 border-t border-gray-50">
                                <button type="submit" class="w-full py-2 bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-lg text-xs transition shadow-sm">
                                    <i class="fa-solid fa-save mr-1"></i> Simpan No. Slip
                                </button>
                                
                                <a href="users.php?reset_slip=true" onclick="return confirm('Apakah Anda yakin ingin mereset sistem No. Slip kembali ke awal (SLIP-0001)?')" 
                                   class="w-full py-2 bg-red-50 hover:bg-red-100 text-red-700 text-center font-bold rounded-lg text-xs transition border border-red-100 flex justify-center items-center gap-1">
                                    <i class="fa-solid fa-arrow-rotate-left text-[10px]"></i> Reset ke SLIP-0001
                                </a>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </main>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-800 text-gray-400 py-3 mt-auto border-t border-gray-700 no-print text-[10px]">
        <div class="container mx-auto px-4 text-center">
            <p class="font-bold text-gray-300">Sistem Informasi Rekapitulasi Bokar (Bahan Olahan Karet)</p>
            <p>&copy; 2026 PT Potensi Bumi Sakti (Arsari Group). All rights reserved.</p>
        </div>
    </footer>

    <!-- Modal untuk Add / Edit User -->
    <div id="userModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center hidden">
        <div class="bg-white rounded-2xl max-w-md w-full mx-4 shadow-2xl overflow-hidden transition-all transform scale-95 opacity-0 duration-300" id="modalContainer">
            <!-- Header -->
            <div class="bg-primary-800 text-white px-6 py-4 flex justify-between items-center">
                <h3 class="font-bold text-lg" id="modalTitle">Tambah Pengguna Baru</h3>
                <button onclick="toggleUserModal('close')" class="text-white hover:text-gray-200 transition">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>
            
            <!-- Form -->
            <form id="userForm" action="users.php" method="POST" class="p-6 space-y-4">
                <input type="hidden" name="action" id="form_action" value="add">
                <input type="hidden" name="user_id" id="edit_user_id">
                
                <div>
                    <label for="edit_fullname" class="block text-sm font-semibold text-gray-700 mb-1">Nama Lengkap</label>
                    <input type="text" name="fullname" id="edit_fullname" required placeholder="Contoh: Budi Santoso"
                           class="w-full px-3 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none text-sm">
                </div>
                
                <div>
                    <label for="edit_username" class="block text-sm font-semibold text-gray-700 mb-1">Username</label>
                    <input type="text" name="username" id="edit_username" required placeholder="Contoh: budi_s"
                           class="w-full px-3 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none text-sm font-mono">
                </div>
                
                <div>
                    <label for="edit_password" class="block text-sm font-semibold text-gray-700 mb-1" id="passwordLabel">Password</label>
                    <input type="password" name="password" id="edit_password" placeholder="Masukkan password..."
                           class="w-full px-3 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none text-sm">
                    <p class="text-xs text-gray-400 mt-1 hidden" id="passwordHelp">Biarkan kosong jika tidak ingin mengubah password.</p>
                </div>
                
                <div>
                    <label for="edit_role" class="block text-sm font-semibold text-gray-700 mb-1">Peran (Role)</label>
                    <select name="role" id="edit_role" required
                            class="w-full px-3 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none text-sm">
                        <option value="user">Petugas / User</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
                
                <!-- Footer Buttons -->
                <div class="flex justify-end space-x-3 pt-4 border-t border-gray-100">
                    <button type="button" onclick="toggleUserModal('close')" class="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-semibold rounded-lg transition">
                        Batal
                    </button>
                    <button type="submit" class="px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white text-sm font-semibold rounded-lg shadow-sm hover:shadow-md transition">
                        Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const userModal = document.getElementById('userModal');
        const modalContainer = document.getElementById('modalContainer');
        const userForm = document.getElementById('userForm');
        const modalTitle = document.getElementById('modalTitle');
        const formAction = document.getElementById('form_action');
        const editUserId = document.getElementById('edit_user_id');
        const editFullname = document.getElementById('edit_fullname');
        const editUsername = document.getElementById('edit_username');
        const editPassword = document.getElementById('edit_password');
        const editRole = document.getElementById('edit_role');
        const passwordLabel = document.getElementById('passwordLabel');
        const passwordHelp = document.getElementById('passwordHelp');

        const setPrefix = document.getElementById('set_prefix');
        const setCounter = document.getElementById('set_counter');
        const slipPreview = document.getElementById('slip_preview');

        function toggleUserModal(action) {
            if (action === 'close') {
                modalContainer.classList.replace('scale-100', 'scale-95');
                modalContainer.classList.replace('opacity-100', 'opacity-0');
                setTimeout(() => {
                    userModal.classList.add('hidden');
                }, 150);
            } else {
                userModal.classList.remove('hidden');
                setTimeout(() => {
                    modalContainer.classList.replace('scale-95', 'scale-100');
                    modalContainer.classList.replace('opacity-0', 'opacity-100');
                }, 10);
            }
        }

        function openAddModal() {
            modalTitle.textContent = "Tambah Pengguna Baru";
            formAction.value = "add";
            editUserId.value = "";
            editFullname.value = "";
            editUsername.value = "";
            editPassword.value = "";
            editPassword.required = true;
            editRole.value = "user";
            
            passwordHelp.classList.add('hidden');
            passwordLabel.textContent = "Password";
            
            toggleUserModal('open');
        }

        function openEditModal(user) {
            modalTitle.textContent = "Ubah Data Pengguna";
            formAction.value = "edit";
            editUserId.value = user.id;
            editFullname.value = user.fullname;
            editUsername.value = user.username;
            editRole.value = user.role;
            
            editPassword.value = "";
            editPassword.required = false;
            passwordHelp.classList.remove('hidden');
            passwordLabel.textContent = "Password Baru";
            
            toggleUserModal('open');
        }

        // Live Slip Preview
        function updateSlipPreview() {
            const prefix = setPrefix.value.toUpperCase();
            let counter = parseInt(setCounter.value) || 1;
            if (counter < 1) counter = 1;

            let formattedCounter = counter.toString();
            while (formattedCounter.length < 4) {
                formattedCounter = "0" + formattedCounter;
            }

            slipPreview.textContent = prefix + formattedCounter;
        }
    </script>
</body>
</html>
