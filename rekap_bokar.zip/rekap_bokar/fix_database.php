<?php
// fix_database.php
// FILE PENOLONG OTOMATIS UNTUK MEMPERBAIKI ERROR 'Unknown column basket_kelompoks'
// Jalankan file ini 1x di browser Anda (contoh: http://localhost/rekap_bokar/fix_database.php)

require_once 'config.php';

echo "<div style='font-family: sans-serif; max-w: 600px; margin: 50px auto; padding: 25px; border-radius: 12px; border: 1px solid #dcfce7; background-color: #f0fdf4; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);'>";
echo "<h2 style='color: #166534; margin-top: 0;'>⚙️ Asisten Perbaikan Database Otomatis</h2>";
echo "<p style='color: #3f6212; font-size: 14px;'>Sedang mendeteksi struktur database lokal Anda...</p>";

try {
    // 1. Cek apakah kolom basket_kelompoks sudah ada
    $check_query = $pdo->query("SHOW COLUMNS FROM `bokar_entries` LIKE 'basket_kelompoks'");
    $column_exists = $check_query->fetch();

    if ($column_exists) {
        echo "<p style='color: #15803d; font-weight: bold;'>✓ Kolom 'basket_kelompoks' sudah terpasang dengan benar di database Anda!</p>";
    } else {
        echo "<p style='color: #854d0e;'>⚠️ Kolom 'basket_kelompoks' belum terpasang. Mencoba melakukan migrasi otomatis...</p>";
        
        // Coba cek apakah kolom lama 'basket_lots' masih ada untuk di-rename
        $check_old = $pdo->query("SHOW COLUMNS FROM `bokar_entries` LIKE 'basket_lots'");
        $old_exists = $check_old->fetch();
        
        if ($old_exists) {
            // Ubah nama kolom basket_lots menjadi basket_kelompoks
            $pdo->exec("ALTER TABLE `bokar_entries` CHANGE `basket_lots` `basket_kelompoks` TEXT NOT NULL");
            echo "<p style='color: #15803d; font-weight: bold;'>✓ Berhasil mengubah nama kolom 'basket_lots' menjadi 'basket_kelompoks' secara otomatis!</p>";
        } else {
            // Cek apakah kolom lama bernama 'basket_parties'
            $check_old_party = $pdo->query("SHOW COLUMNS FROM `bokar_entries` LIKE 'basket_parties'");
            $old_party_exists = $check_old_party->fetch();
            
            if ($old_party_exists) {
                $pdo->exec("ALTER TABLE `bokar_entries` CHANGE `basket_parties` `basket_kelompoks` TEXT NOT NULL");
                echo "<p style='color: #15803d; font-weight: bold;'>✓ Berhasil mengubah nama kolom 'basket_parties' menjadi 'basket_kelompoks' secara otomatis!</p>";
            } else {
                // Jika tidak ada kolom lama sama sekali, kita buatkan kolom baru saja
                $pdo->exec("ALTER TABLE `bokar_entries` ADD `basket_kelompoks` TEXT NOT NULL AFTER `basket_grades`");
                echo "<p style='color: #15803d; font-weight: bold;'>✓ Berhasil membuat kolom baru 'basket_kelompoks' di dalam tabel database Anda!</p>";
            }
        }
    }

    echo "<hr style='border: none; border-top: 1px solid #bbf7d0; margin: 20px 0;'>";
    echo "<p style='color: #166534; font-size: 15px; font-weight: bold;'>🎉 KESUKSESAN: Database lokal Anda kini sudah 100% sinkron!</p>";
    echo "<p style='color: #14532d; font-size: 13px;'>Silakan hapus file <b>fix_database.php</b> ini demi keamanan, lalu buka kembali halaman rekap bokar Anda. Pak Yasro & Bagus sekarang sudah bisa menginput data timbangan dengan lancar jaya!</p>";
    echo "<a href='index.php' style='display: inline-block; background-color: #16a34a; color: white; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-weight: bold; margin-top: 10px; font-size: 13px;'>Kembali ke Dashboard Timbangan</a>";

} catch (Exception $e) {
    echo "<div style='padding: 15px; border-radius: 8px; background-color: #fef2f2; border: 1px solid #fca5a5; color: #991b1b;'>";
    echo "<h4 style='margin-top: 0;'>❌ Gagal Melakukan Perbaikan Otomatis</h4>";
    echo "<p style='font-size: 13px;'>Detail Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p style='font-size: 13px;'><b>Saran Solusi Manual:</b> Buka phpMyAdmin lokal Anda, klik database <b>abdulkar_rekap_bokar</b>, klik tab <b>SQL</b> di atas, jalankan kueri berikut: <br><br><code style='background: white; padding: 6px; border: 1px solid #fca5a5; display: block; font-family: monospace;'>ALTER TABLE bokar_entries ADD basket_kelompoks TEXT NOT NULL;</code></p>";
    echo "</div>";
}

echo "</div>";
?>
