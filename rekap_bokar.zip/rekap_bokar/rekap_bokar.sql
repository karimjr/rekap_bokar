-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 27, 2026 at 01:57 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rekap_bokar`
--

-- --------------------------------------------------------

--
-- Table structure for table `bokar_entries`
--

CREATE TABLE `bokar_entries` (
  `id` int(11) NOT NULL,
  `supplier_name` varchar(150) NOT NULL,
  `slip_number` varchar(50) NOT NULL,
  `origin` varchar(150) NOT NULL,
  `gross_weight` double NOT NULL,
  `gross_weights` text NOT NULL,
  `basket_weights` text NOT NULL,
  `basket_grades` text NOT NULL,
  `basket_kelompoks` text NOT NULL,
  `total_basket_weight` double NOT NULL,
  `net_weight` double NOT NULL,
  `grade_a_weight` double NOT NULL DEFAULT 0,
  `grade_b_weight` double NOT NULL DEFAULT 0,
  `grade_c_weight` double NOT NULL DEFAULT 0,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `supplier_code` varchar(10) NOT NULL,
  `supplier_name` varchar(150) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `supplier_code`, `supplier_name`, `created_at`) VALUES
(1, '001', 'PT. ILHAM KARUNIA NUSANTARA', '2026-10-26 08:29:25'),
(2, '002', 'KURNIAWAN', '2026-10-26 08:29:25'),
(3, '003', 'MISWAR', '2026-10-26 08:29:25'),
(4, '004', 'MUHAMMAD DIAN AMBIA', '2026-10-26 08:29:25'),
(5, '005', 'ABDUL RAFUR', '2026-10-26 08:29:25'),
(6, '006', 'NAZARUDDIN', '2026-10-26 08:29:25'),
(7, '007', 'LUKMAN NUL HAKIM SINAGA', '2026-10-26 08:29:25'),
(8, '008', 'ABD.JALIL.IB', '2026-10-26 08:29:25'),
(9, '009', 'HUSAINI UMAR', '2026-10-26 08:29:25'),
(10, '010', 'AMREN', '2026-10-26 08:29:25'),
(11, '011', 'AMRAN', '2026-10-26 08:29:25'),
(12, '012', 'MERIKO TAMPATI', '2026-10-26 08:29:25'),
(13, '013', 'HAFIZ HAFRIZAL', '2026-10-26 08:29:25'),
(14, '014', 'MUCHTAR', '2026-10-26 08:29:25'),
(15, '015', 'HIDAYAT', '2026-10-26 08:29:25'),
(16, '016', 'BUDIMAN TS', '2026-10-26 08:29:25'),
(17, '017', 'T.HASRAT TD', '2026-10-26 08:29:25'),
(18, '018', 'WANDA HAS', '2026-10-26 08:29:25'),
(19, '019', 'MAHDI JAILANI', '2026-10-26 08:29:25'),
(20, '020', 'ANDRI AGUSI', '2026-10-26 08:29:25'),
(21, '021', 'MUSDAR', '2026-10-26 08:29:25'),
(22, '022', 'MUHIBUDIN', '2026-10-26 08:29:25'),
(23, '023', 'SAID BAHAGIA', '2026-10-26 08:29:25'),
(24, '024', 'H.MALEM MUDA', '2026-10-26 08:29:25'),
(25, '025', 'SAID IDRUS', '2026-10-26 08:29:25'),
(26, '026', 'KEUMALA HAYATI', '2026-10-26 08:29:25'),
(27, '027', 'M.RIZKI FARHAN', '2026-10-26 08:29:25'),
(28, '028', 'AZHARI', '2026-10-26 08:29:25'),
(29, '029', 'ISMAIL', '2026-10-26 08:29:25'),
(30, '030', 'TGK. T MUSLIADI', '2026-10-26 08:29:25'),
(31, '031', 'M. HALI MUDIN', '2026-10-26 08:29:25'),
(32, '032', 'MONA SARI', '2026-10-26 08:29:25'),
(33, '033', 'YUDA', '2026-10-26 08:29:25'),
(34, '034', 'ABDUL AZIZ', '2026-10-26 08:29:25'),
(35, '035', 'EVI DIANA', '2026-10-26 08:29:25'),
(36, '036', 'TEUKU SAIFUL MAHLIL', '2026-10-26 08:29:25'),
(37, '037', 'SUPRIADI', '2026-10-26 08:29:25'),
(38, '038', 'NASRI HAS', '2026-10-26 08:29:25'),
(39, '039', 'SRI WAHYUNI', '2026-10-26 08:29:25'),
(40, '040', 'YUSRI HASBULLAH', '2026-10-26 08:29:25'),
(41, '041', 'ZULFAHMI', '2026-10-26 08:29:25'),
(42, '042', 'H.BAHARUDDIN', '2026-10-26 08:29:25'),
(43, '043', 'SYAHRIL', '2026-10-26 08:29:25'),
(44, '044', 'AZHAR.Z', '2026-10-26 08:29:25'),
(45, '045', 'NADIA ULVA', '2026-10-26 08:29:25'),
(46, '046', 'KHAIDIR IB', '2026-10-26 08:29:25'),
(47, '047', 'ZAINI FADLI', '2026-10-26 08:29:25'),
(48, '048', 'ABDULLAH AS', '2026-10-26 08:29:25'),
(49, '049', 'JADDAM IMAN', '2026-10-26 08:29:25'),
(50, '050', 'FASNIDAWATI', '2026-10-26 08:29:25'),
(51, '051', 'ASRUL', '2026-10-26 08:29:25'),
(52, '052', 'RUDI EDWAR', '2026-10-26 08:29:25'),
(53, '053', 'NASRUDDIN', '2026-10-26 08:29:25'),
(54, '054', 'SAYUSI', '2026-10-26 08:29:25'),
(55, '055', 'ABDUL JALIL', '2026-10-26 08:29:25'),
(56, '056', 'CUT INA MARIANA', '2026-10-26 08:29:25'),
(57, '057', 'SYA\'ARI', '2026-10-26 08:29:25'),
(58, '058', 'TEUKU IWAN WAHYUDI', '2026-10-26 08:29:25'),
(59, '059', 'TGK ZAKARIA AMSAR', '2026-10-26 08:29:25'),
(60, '060', 'AMRI', '2026-10-26 08:29:25'),
(61, '061', 'YENI MIRANDA', '2026-10-26 08:29:25'),
(62, '062', 'FITRI YANI', '2026-10-26 08:29:25'),
(63, '063', 'TUTI ZAHLEKA', '2026-10-26 08:29:25');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `key_name` varchar(50) NOT NULL,
  `key_value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`key_name`, `key_value`) VALUES
('slip_counter', '1'),
('slip_prefix', 'SLIP-');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `fullname`, `role`, `created_at`) VALUES
(1, 'admin', '$2y$12$bglnxySxm6wQObT98inIWeZIHo43hxARqLIkkRPlmVzo5JJ/LGbfS', 'Admin Rekap', 'admin', '2026-10-26 08:29:24'),
(2, 'user', '$2y$12$U/YwplCTZtpdXmgBwWjS7uU2T9qwBV0.PojrHuf66zymdcDAgJ62e', 'Petugas Timbangan', 'user', '2026-10-26 08:29:24'),
(3, 'wina', '$2y$10$sxt3td/KIGGHVMKGFtW5p.wJJpDfRGezKUT3Iky4ZqJ.Hj2F9FFCW', 'Wina', 'user', '2026-10-26 08:37:31'),
(4, 'hanifah', '$2y$10$5JTVdIiJvq8Rl5t6JZ16ceI8AOjPnZmohIE9kC7xupLcoh0WXYG4e', 'Hanifah', 'user', '2026-10-26 08:37:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bokar_entries`
--
ALTER TABLE `bokar_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `supplier_code` (`supplier_code`),
  ADD UNIQUE KEY `supplier_name` (`supplier_name`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`key_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bokar_entries`
--
ALTER TABLE `bokar_entries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3151;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bokar_entries`
--
ALTER TABLE `bokar_entries`
  ADD CONSTRAINT `bokar_entries_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
