<?php
// logout.php
require_once 'config.php';

session_unset();
session_destroy();

session_start();
set_flash('success', 'Anda berhasil keluar dari sistem.');
header("Location: login.php");
exit;
?>
