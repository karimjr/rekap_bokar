<?php
// print.php - Cetak Laporan Rekapitulasi Bokar (MySQL - Split Grade & Dual Basket Weights & Vehicle Number)
require_once 'config.php';
require_login();

// Ambil parameter filter dari URL (GET)
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$supplier = $_GET['supplier'] ?? '';
$origin = $_GET['origin'] ?? '';
$grade_filter = $_GET['grade_filter'] ?? '';

// Bangun query secara dinamis
$query = "SELECT e.*, u.fullname as creator_name 
          FROM bokar_entries e 
          JOIN users u ON e.created_by = u.id 
          WHERE 1=1";
$params = [];

if (!empty($start_date)) {
    $query .= " AND DATE(e.created_at) >= DATE(?)";
    $params[] = $start_date;
}
if (!empty($end_date)) {
    $query .= " AND DATE(e.created_at) <= DATE(?)";
    $params[] = $end_date;
}
if (!empty($supplier)) {
    $query .= " AND e.supplier_name LIKE ?";
    $params[] = "%$supplier%";
}
if (!empty($origin)) {
    $query .= " AND e.origin LIKE ?";
    $params[] = "%$origin%";
}
if ($grade_filter === 'Grade A') {
    $query .= " AND e.grade_a_weight > 0";
} elseif ($grade_filter === 'Grade B') {
    $query .= " AND e.grade_b_weight > 0";
} elseif ($grade_filter === 'Grade C') {
    $query .= " AND e.grade_c_weight > 0";
}

$query .= " ORDER BY e.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$entries = $stmt->fetchAll();

// Kalkulasi statistik keseluruhan
$total_gross = 0.0;
$total_basket = 0.0;
$total_net = 0.0;
$total_grade_a = 0.0;
$total_grade_b = 0.0;
$total_grade_c = 0.0;

foreach ($entries as &$entry) {
    $entry['gross_list'] = json_decode($entry['gross_weights'] ?? '[]', true) ?? [$entry['gross_weight']];
    $entry['baskets_list'] = json_decode($entry['basket_weights'] ?? '[]', true) ?? [$entry['total_basket_weight']];
    
    $total_gross += $entry['gross_weight'];
    $total_basket += $entry['total_basket_weight'];
    $total_net += $entry['net_weight'];
    
    $total_grade_a += $entry['grade_a_weight'];
    $total_grade_b += $entry['grade_b_weight'];
    $total_grade_c += $entry['grade_c_weight'];
}
unset($entry); // safety break reference

$today_str = date('d F Y - H:i:s');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Laporan Rekapitulasi Bokar - PT Potensi Bumi Sakti</title>
    <!-- Tailwind CSS CDN -->
    <link rel="stylesheet" href="assets/css/tailwind.css">
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <style>
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                background: white;
                color: black;
                font-size: 10px;
            }
            table {
                page-break-inside: auto;
            }
            tr {
                page-break-inside: avoid;
                page-break-after: auto;
            }
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen py-8 px-4 sm:px-6 lg:px-8">

    <!-- Action Bar (Tersembunyi saat dicetak) -->
    <div class="max-w-6xl mx-auto mb-6 no-print flex justify-between items-center bg-white p-4 rounded-xl shadow border border-gray-200">
        <div class="flex items-center space-x-3">
            <a href="index.php" class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-2 rounded-lg text-sm font-semibold transition flex items-center gap-1">
                <i class="fa-solid fa-arrow-left"></i> Kembali ke Dashboard
            </a>
            <span class="text-xs text-gray-400">| Preview Laporan Sebelum Dicetak</span>
        </div>
        <button onclick="window.print()" class="bg-green-600 hover:bg-green-700 text-white font-bold px-5 py-2 rounded-lg text-sm shadow transition flex items-center gap-1.5">
            <i class="fa-solid fa-print"></i> Cetak Laporan / Simpan PDF
        </button>
    </div>

    <!-- Main Print Sheet -->
    <div class="max-w-6xl mx-auto bg-white border border-gray-200 p-8 sm:p-12 shadow-md rounded-xl">
        
        <!-- Document Header / Kop Surat -->
        <div class="flex justify-between items-start border-b-2 border-gray-800 pb-6 mb-6">
            <div class="flex items-center space-x-4">
                <div class="bg-green-800 text-white p-3 rounded-xl">
                    <i class="fa-solid fa-tree text-3xl"></i>
                </div>
                <div>
                    <h1 class="text-2xl font-black text-gray-900 tracking-tight">PT Potensi Bumi Sakti (Arsari Group)</h1>
                    <p class="text-xs text-gray-500 font-medium">Jl. Tgk Ibrahim No.Desa, Glee Siblah, Woyla, West Aceh Regency, Aceh 23654</p>
                    <p class="text-xs text-gray-400">Email: info@potensibumisakti.co.id</p>
                </div>
            </div>
            <div class="text-right">
                <span class="text-xs font-bold uppercase text-gray-400 tracking-wider">Laporan Resmi</span>
                <h2 class="text-lg font-black text-gray-800">REKAPITULASI DATA BOKAR</h2>
                <p class="text-xs text-gray-500">Tanggal Cetak: <span class="font-mono"><?php echo $today_str; ?></span></p>
            </div>
        </div>

        <!-- Filter Details -->
        <div class="bg-gray-50 rounded-lg p-4 mb-6 border border-gray-100 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
            <div>
                <span class="text-gray-400 font-semibold uppercase block">Mulai Periode:</span>
                <span class="text-gray-800 font-bold"><?php echo !empty($start_date) ? htmlspecialchars($start_date) : '-'; ?></span>
            </div>
            <div>
                <span class="text-gray-400 font-semibold uppercase block">Sampai Periode:</span>
                <span class="text-gray-800 font-bold"><?php echo !empty($end_date) ? htmlspecialchars($end_date) : '-'; ?></span>
            </div>
            <div>
                <span class="text-gray-400 font-semibold uppercase block">Supplier:</span>
                <span class="text-gray-800 font-bold"><?php echo !empty($supplier) ? htmlspecialchars($supplier) : 'Semua Supplier'; ?></span>
            </div>
            <div>
                <span class="text-gray-400 font-semibold uppercase block">Grade / Asal:</span>
                <span class="text-gray-800 font-bold">
                    <?php echo !empty($grade_filter) ? "Memiliki " . htmlspecialchars($grade_filter) : 'Semua Grade'; ?>
                    / 
                    <?php echo !empty($origin) ? htmlspecialchars($origin) : 'Semua Asal'; ?>
                </span>
            </div>
        </div>

        <!-- Main Data Table -->
        <table class="min-w-full divide-y divide-gray-300 text-left border border-gray-200 rounded-lg mb-8">
            <thead class="bg-gray-50 text-[9px] font-bold text-gray-500 uppercase tracking-wider">
                <tr>
                    <th class="px-2 py-3 border-b border-gray-200">No</th>
                    <th class="px-2 py-3 border-b border-gray-200">No. Slip</th>
                    <th class="px-2 py-3 border-b border-gray-200">No. Polisi</th>
                    <th class="px-2 py-3 border-b border-gray-200 whitespace-nowrap">Tanggal</th>
                    <th class="px-2 py-3 border-b border-gray-200">Nama Supplier</th>
                    <th class="px-2 py-3 border-b border-gray-200">Asal Bokar</th>
                    <th class="px-2 py-3 border-b border-gray-200 text-right">Berat Kotor (Gross)</th>
                    <th class="px-2.5 py-3 border-b border-gray-200 text-center">Rincian [Grade: Gross/Tara]</th>
                    <th class="px-2 py-3 border-b border-gray-200 text-right">Berat Keranjang (Tara)</th>
                    <th class="px-2 py-3 border-b border-gray-200 text-right bg-gray-100">Berat Bersih (Netto)</th>
                    <th class="px-2 py-3 border-b border-gray-200 text-center text-green-700 bg-green-50">Grade A (Kg)</th>
                    <th class="px-2 py-3 border-b border-gray-200 text-center text-blue-700 bg-blue-50">Grade B (Kg)</th>
                    <th class="px-2 py-3 border-b border-gray-200 text-center text-yellow-700 bg-yellow-50">Grade C (Kg)</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100 text-[10px]">
                <?php $idx = 1; foreach ($entries as $entry): ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-2 py-3 font-semibold text-gray-500"><?php echo $idx++; ?></td>
                    <td class="px-2 py-3 font-mono font-bold text-gray-800"><?php echo htmlspecialchars($entry['slip_number']); ?></td>
                    <td class="px-2 py-3 font-mono font-bold text-gray-700 uppercase"><?php echo htmlspecialchars($entry['vehicle_number']); ?></td>
                    <td class="px-2 py-3 text-gray-600 whitespace-nowrap"><?php echo substr($entry['created_at'], 0, 10); ?></td>
                    <td class="px-2 py-3 font-bold text-gray-900"><?php echo htmlspecialchars($entry['supplier_name']); ?></td>
                    <td class="px-2 py-3 text-gray-600"><?php echo htmlspecialchars($entry['origin']); ?></td>
                    <td class="px-2 py-3 text-right font-semibold"><?php echo number_format($entry['gross_weight'], 1); ?> Kg</td>
                    <td class="px-2 py-3 text-center text-[9px] text-gray-500 max-w-xs">
                        <?php 
                        $details_arr = [];
                        for ($i = 0; $i < count($entry['gross_list']); $i++) {
                            $g_val = number_format($entry['gross_list'][$i], 1);
                            $t_val = number_format($entry['baskets_list'][$i], 1);
                            $g_grade = $entry['grades_list'][$i] ?? 'Grade A';
                            $letter = substr($g_grade, -1);
                            $details_arr[] = "Kj" . ($i + 1) . "($letter: $g_val/$t_val)";
                        }
                        echo implode(', ', $details_arr);
                        ?>
                    </td>
                    <td class="px-2 py-3 text-right text-red-600 font-semibold"><?php echo number_format($entry['total_basket_weight'], 1); ?> Kg</td>
                    <td class="px-2 py-3 text-right text-green-700 font-black bg-gray-50"><?php echo number_format($entry['net_weight'], 1); ?> Kg</td>
                    <td class="px-2 py-3 text-center font-bold text-green-800 bg-green-50 bg-opacity-30"><?php echo number_format($entry['grade_a_weight'], 1); ?> Kg</td>
                    <td class="px-2 py-3 text-center font-bold text-blue-800 bg-blue-50 bg-opacity-30"><?php echo number_format($entry['grade_b_weight'], 1); ?> Kg</td>
                    <td class="px-2 py-3 text-center font-bold text-yellow-800 bg-yellow-50 bg-opacity-30"><?php echo number_format($entry['grade_c_weight'], 1); ?> Kg</td>
                </tr>
                <?php endforeach; if (empty($entries)): ?>
                <tr>
                    <td colspan="13" class="px-3 py-8 text-center text-gray-400">
                        Tidak ada data yang sesuai filter.
                    </td>
                </tr>
                <?php endif; ?>

                <!-- Totals Summary Row -->
                <tr class="bg-gray-50 font-bold text-gray-800 text-xs border-t-2 border-gray-300">
                    <td colspan="6" class="px-2 py-4 text-right uppercase tracking-wider font-extrabold border-t border-gray-200">Total Keseluruhan:</td>
                    <td class="px-2 py-4 text-right font-extrabold text-gray-900 border-t border-gray-200"><?php echo number_format($total_gross, 1); ?> Kg</td>
                    <td class="px-2 py-4 text-center border-t border-gray-200">-</td>
                    <td class="px-2 py-4 text-right text-red-600 font-extrabold border-t border-gray-200"><?php echo number_format($total_basket, 1); ?> Kg</td>
                    <td class="px-2 py-4 text-right text-green-800 font-black bg-gray-100 border-t border-gray-300"><?php echo number_format($total_net, 1); ?> Kg</td>
                    <td class="px-2 py-4 text-center text-green-900 bg-green-100 border-t border-gray-300"><?php echo number_format($total_grade_a, 1); ?> Kg</td>
                    <td class="px-2 py-4 text-center text-blue-900 bg-blue-100 border-t border-gray-300"><?php echo number_format($total_grade_b, 1); ?> Kg</td>
                    <td class="px-2 py-4 text-center text-yellow-900 bg-yellow-100 border-t border-gray-300"><?php echo number_format($total_grade_c, 1); ?> Kg</td>
                </tr>
            </tbody>
        </table>

        <!-- Signatures -->
        <div class="grid grid-cols-2 gap-8 mt-12 pt-8 border-t border-gray-100 text-xs">
            <div class="text-center">
                <p class="text-gray-400 font-medium mb-1">Dibuat & Diverifikasi Oleh:</p>
                <p class="font-bold text-gray-800 uppercase tracking-wide">Petugas Gudang / Timbangan</p>
                <div class="h-20 flex items-center justify-center">
                    <span class="text-gray-300 italic text-[11px]">[ Tanda Tangan & Cap ]</span>
                </div>
                <hr class="w-48 mx-auto border-gray-400">
                <p class="mt-2 font-bold text-gray-800">....................................................</p>
                <p class="text-[10px] text-gray-400">PT Potensi Bumi Sakti (Arsari Group)</p>
            </div>
            
            <div class="text-center">
                <p class="text-gray-400 font-medium mb-1">Diketahui & Disetujui Oleh:</p>
                <p class="font-bold text-gray-800 uppercase tracking-wide">Kepala Bagian Operasional</p>
                <div class="h-20 flex items-center justify-center">
                    <span class="text-gray-300 italic text-[11px]">[ Tanda Tangan & Cap ]</span>
                </div>
                <hr class="w-48 mx-auto border-gray-400">
                <p class="mt-2 font-bold text-gray-800">....................................................</p>
                <p class="text-[10px] text-gray-400">PT Potensi Bumi Sakti (Arsari Group)</p>
            </div>
        </div>

        <!-- Print Instructions -->
        <div class="mt-8 bg-blue-50 text-blue-800 p-4 rounded-lg text-xs flex items-start gap-2.5 no-print">
            <i class="fa-solid fa-circle-info text-blue-600 mt-0.5"></i>
            <div>
                <p class="font-bold">Tips Mencetak PDF yang Sempurna:</p>
                <ul class="list-disc pl-4 mt-1 space-y-1">
                    <li>Pilih opsi <strong>"Save as PDF"</strong> atau printer fisik Anda setelah mengeklik tombol Cetak di atas.</li>
                    <li>Centang opsi <strong>"Background graphics"</strong> (Grafis latar belakang) agar warna tabel dan grade tetap terlihat indah.</li>
                    <li>Atur orientasi kertas menjadi <strong>"Landscape"</strong> jika data kolom terasa terlalu rapat.</li>
                </ul>
            </div>
        </div>

    </div>
</body>
</html>
