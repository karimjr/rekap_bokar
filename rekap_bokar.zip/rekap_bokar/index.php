<?php
// index.php - Dashboard Utama Rekapitulasi Bokar (MySQL - Multi-Kelompok per Slip & Sleek Tab Menu)
require_once 'config.php';
require_login();

// --------------------------------------------------------
// HANDLER: HAPUS REKAP (GET)
// --------------------------------------------------------
if (isset($_GET['delete_entry'])) {
    $delete_id = (int)$_GET['delete_entry'];
    
    $stmt = $pdo->prepare("SELECT slip_number FROM bokar_entries WHERE id = ?");
    $stmt->execute([$delete_id]);
    $slip = $stmt->fetchColumn();
    
    if ($slip) {
        $stmt = $pdo->prepare("DELETE FROM bokar_entries WHERE id = ?");
        $stmt->execute([$delete_id]);
        set_flash('success', "Data rekap bokar No. Slip $slip berhasil dihapus!");
    } else {
        set_flash('error', 'Data tidak ditemukan.');
    }
    header("Location: index.php");
    exit;
}

// --------------------------------------------------------
// HANDLER: TAMBAH REKAP (POST)
// --------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $supplier_name = trim($_POST['supplier_name']);
    $origin = trim($_POST['origin']);
    $vehicle_number = strtoupper(trim($_POST['vehicle_number'] ?? '-'));
    $created_at_date = $_POST['created_at'];
    
    // Ambil array Kelompok Timbang
    $kelompok_names = $_POST['kelompok_name'] ?? [];
    
    $gross_list = [];
    $basket_list = [];
    $grade_list = [];
    $kelompok_list = [];
    
    $total_gross_weight = 0.0;
    $total_basket_weight = 0.0;
    
    $grade_a_total = 0.0;
    $grade_b_total = 0.0;
    $grade_c_total = 0.0;
    
    // Iterasi setiap Kelompok Timbang yang diinput
    for ($p = 0; $s_idx = $p, $p < count($kelompok_names); $p++) {
        $kelompok_name = trim($kelompok_names[$p]);
        if (empty($kelompok_name)) {
            $kelompok_name = "Kelompok " . ($p + 1);
        }
        
        // Ambil array timbangan per masing-masing seksi grade untuk kelompok index ini
        $gross_a = $_POST["gross_weights_a_$p"] ?? [];
        $tara_a = $_POST["basket_weights_a_$p"] ?? [];
        
        $gross_b = $_POST["gross_weights_b_$p"] ?? [];
        $tara_b = $_POST["basket_weights_b_$p"] ?? [];
        
        $gross_c = $_POST["gross_weights_c_$p"] ?? [];
        $tara_c = $_POST["basket_weights_c_$p"] ?? [];
        
        // Proses Grade A
        for ($i = 0; $i < count($gross_a); $i++) {
            $g = (double)$gross_a[$i];
            $t = (double)($tara_a[$i] ?? 0);
            if ($g > 0) {
                $gross_list[] = $g;
                $basket_list[] = $t;
                $grade_list[] = 'Grade A';
                $kelompok_list[] = $kelompok_name;
                $total_gross_weight += $g;
                $total_basket_weight += $t;
                $grade_a_total += ($g - $t);
            }
        }
        
        // Proses Grade B
        for ($i = 0; $i < count($gross_b); $i++) {
            $g = (double)$gross_b[$i];
            $t = (double)($tara_b[$i] ?? 0);
            if ($g > 0) {
                $gross_list[] = $g;
                $basket_list[] = $t;
                $grade_list[] = 'Grade B';
                $kelompok_list[] = $kelompok_name;
                $total_gross_weight += $g;
                $total_basket_weight += $t;
                $grade_b_total += ($g - $t);
            }
        }
        
        // Proses Grade C
        for ($i = 0; $i < count($gross_c); $i++) {
            $g = (double)$gross_c[$i];
            $t = (double)($tara_c[$i] ?? 0);
            if ($g > 0) {
                $gross_list[] = $g;
                $basket_list[] = $t;
                $grade_list[] = 'Grade C';
                $kelompok_list[] = $kelompok_name;
                $total_gross_weight += $g;
                $total_basket_weight += $t;
                $grade_c_total += ($g - $t);
            }
        }
    }
    
    $net_weight = $total_gross_weight - $total_basket_weight;
    
    if (!empty($supplier_name) && !empty($origin) && $total_gross_weight > 0) {
        $gross_weights_json = json_encode($gross_list);
        $basket_weights_json = json_encode($basket_list);
        $basket_grades_json = json_encode($grade_list);
        $basket_kelompoks_json = json_encode($kelompok_list);
        
        try {
            $slip_number = get_next_slip_number($pdo);
            $full_timestamp = $created_at_date . " " . date('H:i:s');
            
            $stmt = $pdo->prepare("INSERT INTO bokar_entries (supplier_name, slip_number, vehicle_number, origin, gross_weight, gross_weights, basket_weights, basket_grades, basket_kelompoks, total_basket_weight, net_weight, grade_a_weight, grade_b_weight, grade_c_weight, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $supplier_name, $slip_number, $vehicle_number, $origin, $total_gross_weight, $gross_weights_json, 
                $basket_weights_json, $basket_grades_json, $basket_kelompoks_json, $total_basket_weight, $net_weight, 
                $grade_a_total, $grade_b_total, $grade_c_total, 
                $_SESSION['user_id'], $full_timestamp
            ]);
            
            increment_slip_counter($pdo);
            
            set_flash('success', "Berhasil menyimpan rekap bokar No. Slip $slip_number untuk supplier $supplier_name! Rincian timbangan per Kelompok digabungkan dalam 1 nota.");
        } catch (PDOException $e) {
            set_flash('error', "Gagal menyimpan data: " . $e->getMessage());
        }
    } else {
        set_flash('error', 'Harap isi rincian timbangan Kelompok dengan benar.');
    }
    header("Location: index.php");
    exit;
}

// --------------------------------------------------------
// HANDLER: EDIT REKAP (POST)
// --------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $entry_id = (int)$_POST['entry_id'];
    $supplier_name = trim($_POST['supplier_name']);
    $origin = trim($_POST['origin']);
    $vehicle_number = strtoupper(trim($_POST['vehicle_number'] ?? '-'));
    $created_at_date = $_POST['created_at'];
    
    // Pada EDIT, kita mengedit SATU Kelompok timbangan (index 0)
    $kelompok_name = trim($_POST['kelompok_name'][0] ?? 'Kelompok 1');
    
    $gross_a = $_POST['gross_weights_a_0'] ?? [];
    $tara_a = $_POST['basket_weights_a_0'] ?? [];
    
    $gross_b = $_POST['gross_weights_b_0'] ?? [];
    $tara_b = $_POST['basket_weights_b_0'] ?? [];
    
    $gross_c = $_POST['gross_weights_c_0'] ?? [];
    $tara_c = $_POST['basket_weights_c_0'] ?? [];
    
    $gross_list = [];
    $basket_list = [];
    $grade_list = [];
    $kelompok_list = [];
    
    $total_gross_weight = 0.0;
    $total_basket_weight = 0.0;
    
    $grade_a_total = 0.0;
    $grade_b_total = 0.0;
    $grade_c_total = 0.0;
    
    // Proses Grade A
    for ($i = 0; $i < count($gross_a); $i++) {
        $g = (double)$gross_a[$i];
        $t = (double)($tara_a[$i] ?? 0);
        if ($g > 0) {
            $gross_list[] = $g;
            $basket_list[] = $t;
            $grade_list[] = 'Grade A';
            $kelompok_list[] = $kelompok_name;
            $total_gross_weight += $g;
            $total_basket_weight += $t;
            $grade_a_total += ($g - $t);
        }
    }
    
    // Proses Grade B
    for ($i = 0; $i < count($gross_b); $i++) {
        $g = (double)$gross_b[$i];
        $t = (double)($tara_b[$i] ?? 0);
        if ($g > 0) {
            $gross_list[] = $g;
            $basket_list[] = $t;
            $grade_list[] = 'Grade B';
            $kelompok_list[] = $kelompok_name;
            $total_gross_weight += $g;
            $total_basket_weight += $t;
            $grade_b_total += ($g - $t);
        }
    }
    
    // Proses Grade C
    for ($i = 0; $i < count($gross_c); $i++) {
        $g = (double)$gross_c[$i];
        $t = (double)($tara_c[$i] ?? 0);
        if ($g > 0) {
            $gross_list[] = $g;
            $basket_list[] = $t;
            $grade_list[] = 'Grade C';
            $kelompok_list[] = $kelompok_name;
            $total_gross_weight += $g;
            $total_basket_weight += $t;
            $grade_c_total += ($g - $t);
        }
    }
    
    $net_weight = $total_gross_weight - $total_basket_weight;
    $gross_weights_json = json_encode($gross_list);
    $basket_weights_json = json_encode($basket_list);
    $basket_grades_json = json_encode($grade_list);
    $basket_kelompoks_json = json_encode($kelompok_list);
    
    if (!empty($entry_id) && !empty($supplier_name) && !empty($origin) && $total_gross_weight > 0) {
        try {
            $stmt = $pdo->prepare("SELECT created_at, slip_number FROM bokar_entries WHERE id = ?");
            $stmt->execute([$entry_id]);
            $old_row = $stmt->fetch();
            $old_ts = $old_row['created_at'] ?? '';
            $slip_number = $old_row['slip_number'] ?? '';
            
            if ($old_ts && strpos($old_ts, $created_at_date) === 0) {
                $full_timestamp = $old_ts;
            } else {
                $full_timestamp = $created_at_date . " " . date('H:i:s');
            }
            
            $stmt = $pdo->prepare("UPDATE bokar_entries SET supplier_name = ?, origin = ?, vehicle_number = ?, gross_weight = ?, gross_weights = ?, basket_weights = ?, basket_grades = ?, basket_kelompoks = ?, total_basket_weight = ?, net_weight = ?, grade_a_weight = ?, grade_b_weight = ?, grade_c_weight = ?, created_at = ? WHERE id = ?");
            $stmt->execute([
                $supplier_name, $origin, $vehicle_number, $total_gross_weight, $gross_weights_json, $basket_weights_json, $basket_grades_json, $basket_kelompoks_json, 
                $total_basket_weight, $net_weight, $grade_a_total, $grade_b_total, $grade_c_total, 
                $full_timestamp, $entry_id
            ]);
            
            set_flash('success', "Data rekap bokar No. Slip $slip_number berhasil diperbarui!");
        } catch (PDOException $e) {
            set_flash('error', "Gagal memperbarui data: " . $e->getMessage());
        }
    } else {
        set_flash('error', 'Harap isi rincian timbangan Kelompok dengan benar.');
    }
    header("Location: index.php");
    exit;
}

// --------------------------------------------------------
// AMBIL FILTER & DATA REKAP (GET)
// --------------------------------------------------------
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$supplier = $_GET['supplier'] ?? '';
$origin = $_GET['origin'] ?? '';
$vehicle = $_GET['vehicle'] ?? '';

$query = "SELECT e.*, u.fullname as creator_name 
          FROM bokar_entries e 
          JOIN users u ON e.created_by = u.id 
          WHERE 1=1";
$params = [];

if (!empty($start_date)) {
    $query .= " AND DATE(e.created_at) >= DATE(?)";
    $params[] = $start_date;
}
if (!empty($end_date)) {
    $query .= " AND DATE(e.created_at) <= DATE(?)";
    $params[] = $end_date;
}
if (!empty($supplier)) {
    $query .= " AND e.supplier_name LIKE ?";
    $params[] = "%$supplier%";
}
if (!empty($origin)) {
    $query .= " AND e.origin LIKE ?";
    $params[] = "%$origin%";
}
if (!empty($vehicle)) {
    $query .= " AND e.vehicle_number LIKE ?";
    $params[] = "%$vehicle%";
}

$query .= " ORDER BY e.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$entries = $stmt->fetchAll();

// Kalkulasi statistik keseluruhan
$total_gross = 0.0;
$total_basket = 0.0;
$total_net = 0.0;
$total_grade_a = 0.0;
$total_grade_b = 0.0;
$total_grade_c = 0.0;

foreach ($entries as &$entry) {
    $entry['gross_list'] = json_decode($entry['gross_weights'] ?? '[]', true) ?? [$entry['gross_weight']];
    $entry['baskets_list'] = json_decode($entry['basket_weights'] ?? '[]', true) ?? [$entry['total_basket_weight']];
    $entry['grades_list'] = json_decode($entry['basket_grades'] ?? '[]', true) ?? [];
    $entry['kelompoks_list'] = json_decode($entry['basket_kelompoks'] ?? '[]', true) ?? [];
    
    if (empty($entry['grades_list'])) {
        $entry['grades_list'] = array_fill(0, count($entry['gross_list']), 'Grade A');
    }
    if (empty($entry['kelompoks_list'])) {
        $entry['kelompoks_list'] = array_fill(0, count($entry['gross_list']), 'Kelompok 1');
    }
    
    $total_gross += $entry['gross_weight'];
    $total_basket += $entry['total_basket_weight'];
    $total_net += $entry['net_weight'];
    
    $total_grade_a += $entry['grade_a_weight'];
    $total_grade_b += $entry['grade_b_weight'];
    $total_grade_c += $entry['grade_c_weight'];
}
unset($entry); // safety break
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekapitulasi Bokar - PT Potensi Bumi Sakti (Arsari Group)</title>
    <!-- Tailwind CSS CDN -->
    <link rel="stylesheet" href="assets/css/tailwind.css">
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
</head>
<body class="bg-gray-100 text-gray-800 flex flex-col min-h-screen font-sans text-xs sm:text-sm">

    <!-- Header / Navbar -->
    <header class="bg-primary-800 text-white shadow-sm no-print py-2">
        <div class="max-w-7xl mx-auto px-4 flex justify-between items-center">
            <a href="index.php" class="flex items-center space-x-2">
                <div class="bg-white p-1 rounded-full text-primary-800">
                    <i class="fa-solid fa-tree text-lg"></i>
                </div>
                <div>
                    <h1 class="text-base font-extrabold tracking-tight leading-none">Rekapitulasi Bokar</h1>
                    <p class="text-[10px] text-primary-200">PT Potensi Bumi Sakti (Arsari Group)</p>
                </div>
            </a>
            
            <div class="flex items-center space-x-3">
                <span class="text-xs bg-primary-700 px-2.5 py-1 rounded-lg flex items-center space-x-1.5">
                    <i class="fa-solid fa-user-circle"></i>
                    <span><strong><?php echo htmlspecialchars($_SESSION['fullname']); ?></strong> (<?php echo ucfirst($_SESSION['role']); ?>)</span>
                </span>
                <a href="logout.php" class="bg-red-600 hover:bg-red-700 text-white px-2.5 py-1 rounded-lg text-xs font-bold transition flex items-center space-x-1">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    <span class="hidden sm:inline">Logout</span>
                </a>
            </div>
        </div>
    </header>

    <!-- Main Navigation & Layout -->
    <div class="flex-grow flex flex-col md:flex-row max-w-7xl w-full mx-auto px-4 py-4 gap-4">
        
        <!-- Sidebar Navigation -->
        <aside class="w-full md:w-52 flex-shrink-0 no-print">
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-3 space-y-1.5">
                <p class="text-[10px] font-bold text-gray-400 uppercase tracking-wider px-2 mb-1">Main Menu</p>
                
                <a href="index.php" class="flex items-center space-x-2 px-2.5 py-2 rounded-lg text-xs font-semibold bg-primary-50 text-primary-700 border-l-4 border-primary-600 transition">
                    <i class="fa-solid fa-chart-line w-4"></i>
                    <span>Dashboard</span>
                </a>
                
                <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="users.php" class="flex items-center space-x-2 px-2.5 py-2 rounded-lg text-xs font-semibold text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition">
                    <i class="fa-solid fa-users-gear w-4"></i>
                    <span>Kelola Pengguna</span>
                </a>
                <?php endif; ?>
                
                <hr class="my-3 border-gray-100">
                
                <div class="p-2.5 bg-green-50 rounded-lg text-[11px] text-primary-800 leading-relaxed">
                    <p class="font-bold mb-0.5"><i class="fa-solid fa-circle-info"></i> Timbangan Pintar</p>
                    <p>Input data beberapa Kelompok Timbang untuk 1 Supplier di satu kendaraan. Hasil bersih dan nota tergabung rapi!</p>
                </div>
            </div>
        </aside>

        <!-- Content Area -->
        <main class="flex-grow space-y-4">
            <!-- Flash Messages -->
            <?php display_flash(); ?>

            <!-- Top Row Statistics -->
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 no-print">
                <div class="bg-gradient-to-br from-primary-700 to-primary-900 text-white rounded-xl shadow-sm p-4 flex items-center justify-between">
                    <div>
                        <p class="text-[10px] text-primary-100 font-bold uppercase tracking-wider leading-none">Berat Bersih (Netto)</p>
                        <h3 class="text-lg font-black mt-1"><?php echo number_format($total_net, 1); ?> Kg</h3>
                        <p class="text-[9px] text-primary-200">Total bersih terakumulasi</p>
                    </div>
                    <div class="bg-primary-600 bg-opacity-30 p-2.5 rounded-lg text-white">
                        <i class="fa-solid fa-scale-balanced text-xl"></i>
                    </div>
                </div>

                <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-4 flex items-center justify-between">
                    <div>
                        <p class="text-[10px] text-green-600 font-bold uppercase tracking-wider leading-none">Total Grade A</p>
                        <h3 class="text-lg font-black text-gray-800 mt-1"><?php echo number_format($total_grade_a, 1); ?> Kg</h3>
                        <p class="text-[9px] text-gray-400">Kualitas Premium (A)</p>
                    </div>
                    <div class="bg-green-50 p-2 rounded-lg text-green-600 border border-green-100 text-sm font-bold">A</div>
                </div>

                <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-4 flex items-center justify-between">
                    <div>
                        <p class="text-[10px] text-blue-600 font-bold uppercase tracking-wider leading-none">Total Grade B</p>
                        <h3 class="text-lg font-black text-gray-800 mt-1"><?php echo number_format($total_grade_b, 1); ?> Kg</h3>
                        <p class="text-[9px] text-gray-400">Kualitas Medium (B)</p>
                    </div>
                    <div class="bg-blue-50 p-2 rounded-lg text-blue-600 border border-blue-100 text-sm font-bold">B</div>
                </div>

                <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-4 flex items-center justify-between">
                    <div>
                        <p class="text-[10px] text-yellow-600 font-bold uppercase tracking-wider leading-none">Total Grade C</p>
                        <h3 class="text-lg font-black text-gray-800 mt-1"><?php echo number_format($total_grade_c, 1); ?> Kg</h3>
                        <p class="text-[9px] text-gray-400">Kualitas Rendah (C)</p>
                    </div>
                    <div class="bg-yellow-50 p-2 rounded-lg text-yellow-600 border border-yellow-100 text-sm font-bold">C</div>
                </div>
            </div>

            <!-- Action Bar: Filter & Add Entry -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4 space-y-3 no-print">
                <div class="flex justify-between items-center flex-wrap gap-2 border-b border-gray-100 pb-2">
                    <div>
                        <h3 class="font-bold text-gray-800 text-sm flex items-center gap-1.5">
                            <i class="fa-solid fa-filter text-primary-600"></i> Filter & Pencarian Laporan
                        </h3>
                    </div>
                    <button onclick="openAddEntryModal('<?php echo get_next_slip_number($pdo); ?>')" class="bg-primary-600 hover:bg-primary-700 text-white font-bold px-3 py-1.5 rounded-lg text-xs shadow flex items-center gap-1.5 transition">
                        <i class="fa-solid fa-plus-circle text-xs"></i> Tambah Rekap Bokar
                    </button>
                </div>

                <!-- Search & Filter Form -->
                <form method="GET" action="index.php" class="grid grid-cols-2 md:grid-cols-5 gap-2" id="filterForm">
                    <div>
                        <label class="block text-[9px] font-bold text-gray-400 uppercase mb-0.5">Mulai Tanggal</label>
                        <input type="date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>" 
                               class="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition">
                    </div>
                    <div>
                        <label class="block text-[9px] font-bold text-gray-400 uppercase mb-0.5">Sampai Tanggal</label>
                        <input type="date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>" 
                               class="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition">
                    </div>
                    <div>
                        <label class="block text-[9px] font-bold text-gray-400 uppercase mb-0.5">Nama Supplier</label>
                        <input type="text" name="supplier" value="<?php echo htmlspecialchars($supplier); ?>" placeholder="Nama supplier..." 
                               class="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition">
                    </div>
                    <div>
                        <label class="block text-[9px] font-bold text-gray-400 uppercase mb-0.5">Asal Bokar</label>
                        <input type="text" name="origin" value="<?php echo htmlspecialchars($origin); ?>" placeholder="Asal daerah..." 
                               class="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition">
                    </div>
                    <div>
                        <label class="block text-[9px] font-bold text-gray-400 uppercase mb-0.5">No. Kendaraan (Truk)</label>
                        <input type="text" name="vehicle" value="<?php echo htmlspecialchars($vehicle); ?>" placeholder="Contoh: BL 1234 A" 
                               class="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition font-mono uppercase">
                    </div>

                    <!-- Submit & Export Buttons -->
                    <div class="col-span-2 md:col-span-5 flex flex-wrap justify-between items-center pt-1.5 gap-2 border-t border-gray-50">
                        <div class="flex space-x-1.5">
                            <button type="submit" class="bg-primary-700 hover:bg-primary-800 text-white font-bold px-3 py-1.5 rounded-lg text-xs transition flex items-center gap-1">
                                <i class="fa-solid fa-magnifying-glass text-[10px]"></i> Cari / Filter
                            </button>
                            <a href="index.php" class="bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold px-3 py-1.5 rounded-lg text-xs transition flex items-center gap-1">
                                <i class="fa-solid fa-rotate-left text-[10px]"></i> Reset
                            </a>
                        </div>

                        <div class="flex space-x-1.5">
                            <button type="button" onclick="exportExcel()" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3 py-1.5 rounded-lg text-xs transition flex items-center gap-1">
                                <i class="fa-solid fa-file-excel text-[10px]"></i> Ekspor ke Excel
                            </button>
                            <button type="button" onclick="printPage()" class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-3 py-1.5 rounded-lg text-xs transition flex items-center gap-1">
                                <i class="fa-solid fa-print text-[10px]"></i> Cetak Laporan
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Main Data Table -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="p-3.5 border-b border-gray-100 flex flex-wrap justify-between items-center gap-2 no-print bg-gray-50 bg-opacity-40">
                    <h3 class="font-extrabold text-gray-800 text-xs flex items-center gap-1.5">
                        <i class="fa-solid fa-table-list text-primary-600"></i> Daftar Timbangan Bokar
                    </h3>
                    
                    <div class="flex items-center gap-2">
                        <button type="button" onclick="printSelectedNotas()" id="printNotaBtn" 
                                class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-3 py-1.5 rounded-lg text-xs shadow transition flex items-center gap-1 opacity-60 cursor-not-allowed" disabled>
                            <i class="fa-solid fa-receipt text-[10px]"></i> Cetak Nota Terpilih (<span id="selectedCount" class="font-black">0</span>)
                        </button>
                        <span class="text-[10px] bg-gray-200 text-gray-700 px-2 py-0.5 rounded-full font-bold">
                            <?php echo count($entries); ?> Slip
                        </span>
                    </div>
                </div>

                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 text-left">
                        <thead class="bg-gray-50 text-[10px] font-bold text-gray-500 uppercase tracking-wider">
                            <tr>
                                <th class="px-2.5 py-2 text-center no-print w-8">
                                    <input type="checkbox" id="selectAll" onclick="toggleSelectAll(this)" 
                                           class="w-3.5 h-3.5 text-primary-600 border-gray-300 rounded focus:ring-primary-500 cursor-pointer">
                                </th>
                                <th class="px-2.5 py-2">No. Slip</th>
                                <th class="px-2.5 py-2">No. Polisi</th>
                                <th class="px-2.5 py-2">Tanggal</th>
                                <th class="px-2.5 py-2">Supplier</th>
                                <th class="px-2.5 py-2">Asal</th>
                                <th class="px-2.5 py-2 text-right">Gross Total</th>
                                <th class="px-2 text-center">Rincian [Kelompok / Grade / Gross / Tara]</th>
                                <th class="px-2 py-2 text-right">Tara Total</th>
                                <th class="px-2.5 py-2 text-right bg-primary-50 bg-opacity-30 text-primary-900 font-extrabold">Netto Total</th>
                                <th class="px-2.5 py-2 text-center">Rincian Grade (Kg)</th>
                                <th class="px-2.5 py-2 no-print">Petugas</th>
                                <th class="px-2.5 py-2 text-right no-print w-16">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-100 text-xs">
                            <?php foreach ($entries as $entry): ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-2.5 py-1.5 text-center no-print">
                                    <input type="checkbox" name="selected_slips[]" value="<?php echo $entry['id']; ?>" 
                                           class="slip-checkbox w-3.5 h-3.5 text-primary-600 border-gray-300 rounded focus:ring-primary-500 cursor-pointer"
                                           onchange="updateSelectedCount()">
                                </td>
                                <td class="px-2.5 py-1.5 font-mono font-bold text-primary-950"><?php echo htmlspecialchars($entry['slip_number']); ?></td>
                                <td class="px-2.5 py-1.5 font-mono font-extrabold text-gray-700 uppercase whitespace-nowrap"><?php echo htmlspecialchars($entry['vehicle_number']); ?></td>
                                <td class="px-2.5 py-1.5 text-gray-500 whitespace-nowrap"><?php echo substr($entry['created_at'], 0, 10); ?></td>
                                <td class="px-2.5 py-1.5 font-bold text-gray-900"><?php echo htmlspecialchars($entry['supplier_name']); ?></td>
                                <td class="px-2.5 py-1.5 text-gray-600 whitespace-nowrap"><?php echo htmlspecialchars($entry['origin']); ?></td>
                                <td class="px-2.5 py-1.5 text-right font-semibold text-gray-800"><?php echo number_format($entry['gross_weight'], 1); ?> Kg</td>
                                <td class="px-2 py-1.5 text-center">
                                    <div class="flex flex-wrap justify-center gap-0.5 max-w-xs mx-auto">
                                        <?php 
                                        for ($i = 0; $i < count($entry['gross_list']); $i++): 
                                            $g_val = $entry['gross_list'][$i] ?? 0;
                                            $t_val = $entry['baskets_list'][$i] ?? 0;
                                            $g_grade = $entry['grades_list'][$i] ?? 'A';
                                            $g_kelompok = $entry['kelompoks_list'][$i] ?? 'Kelompok 1';
                                            $letter = substr($g_grade, -1);
                                        ?>
                                        <span class="bg-gray-100 text-gray-600 text-[9px] px-1 py-0.2 rounded border border-gray-200">
                                            <?php echo htmlspecialchars($g_kelompok); ?>(<?php echo $letter; ?>): [<?php echo number_format($g_val,1); ?>/<?php echo number_format($t_val,1); ?>]
                                        </span>
                                        <?php endfor; ?>
                                    </div>
                                </td>
                                <td class="px-2 py-1.5 text-right text-red-600 font-semibold"><?php echo number_format($entry['total_basket_weight'], 1); ?> Kg</td>
                                <td class="px-2.5 py-1.5 text-right text-primary-700 font-extrabold bg-primary-50 bg-opacity-30"><?php echo number_format($entry['net_weight'], 1); ?> Kg</td>
                                <td class="px-2.5 py-1.5">
                                    <div class="flex space-x-1 justify-center text-[10px]">
                                        <span class="bg-green-50 text-green-700 border border-green-100 px-1 py-0.2 rounded font-bold">
                                            A: <?php echo number_format($entry['grade_a_weight'], 1); ?>
                                        </span>
                                        <span class="bg-blue-50 text-blue-700 border border-blue-100 px-1 py-0.2 rounded font-bold">
                                            B: <?php echo number_format($entry['grade_b_weight'], 1); ?>
                                        </span>
                                        <span class="bg-yellow-50 text-yellow-700 border border-yellow-200 px-1 py-0.2 rounded font-bold">
                                            C: <?php echo number_format($entry['grade_c_weight'], 1); ?>
                                        </span>
                                    </div>
                                </td>
                                <td class="px-2.5 py-1.5 text-gray-500 text-[10px] whitespace-nowrap no-print"><?php echo htmlspecialchars($entry['creator_name']); ?></td>
                                <td class="px-2.5 py-1.5 text-right font-semibold space-x-1 whitespace-nowrap no-print">
                                    <button onclick='editEntry(<?php echo json_encode($entry); ?>)' class="text-primary-600 hover:underline bg-primary-50 px-1.5 py-0.5 rounded text-[10px] font-bold">
                                        Edit
                                    </button>
                                    <a href="index.php?delete_entry=<?php echo $entry['id']; ?>" onclick="return confirm('Hapus slip <?php echo htmlspecialchars($entry['slip_number']); ?>?')" class="text-red-600 hover:underline bg-red-50 px-1.5 py-0.5 rounded text-[10px] font-bold">
                                        Hapus
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; if (empty($entries)): ?>
                            <tr>
                                <td colspan="12" class="px-6 py-8 text-center text-xs text-gray-400">
                                    Tidak ditemukan data rekapitulasi bokar.
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-800 text-gray-400 py-3 mt-auto border-t border-gray-700 no-print text-[10px]">
        <div class="container mx-auto px-4 text-center">
            <p class="font-bold text-gray-300">Sistem Informasi Rekapitulasi Bokar (Bahan Olahan Karet)</p>
            <p>&copy; 2026 PT Potensi Bumi Sakti (Arsari Group). All rights reserved.</p>
        </div>
    </footer>

    <!-- Modal Dialog Tambah & Edit Bokar -->
    <div id="entryModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center hidden">
        <div class="bg-white rounded-2xl max-w-lg w-full mx-4 shadow-2xl overflow-hidden transition-all transform scale-95 opacity-0 duration-300" id="entryModalContainer">
            
            <div class="bg-primary-800 text-white px-5 py-3 flex justify-between items-center">
                <h3 class="font-extrabold text-sm" id="entryModalTitle">Input Hasil Timbangan</h3>
                <button onclick="closeEntryModal()" class="text-white hover:text-gray-200 transition">
                    <i class="fa-solid fa-xmark text-base"></i>
                </button>
            </div>
            
            <form id="entryForm" action="index.php" method="POST" class="p-5 space-y-3 max-h-[85vh] overflow-y-auto">
                <input type="hidden" name="action" id="entry_action" value="add">
                <input type="hidden" name="entry_id" id="edit_entry_id">
                
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-[10px] font-bold text-gray-500 uppercase mb-0.5">No. Slip</label>
                        <input type="text" name="slip_display" id="form_slip" readonly
                               class="w-full px-2.5 py-1.5 rounded-lg border border-gray-300 bg-gray-100 text-gray-500 font-bold text-xs font-mono uppercase cursor-not-allowed">
                    </div>
                    <div>
                        <label class="block text-[10px] font-bold text-gray-500 uppercase mb-0.5">Tanggal *</label>
                        <input type="date" name="created_at" id="form_date" required
                               class="w-full px-2.5 py-1.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none text-xs font-semibold">
                    </div>
                </div>

                <div class="grid grid-cols-3 gap-3">
                    <div>
                        <label class="block text-[10px] font-bold text-gray-500 uppercase mb-0.5">Nama Supplier *</label>
                        <input type="text" name="supplier_name" id="form_supplier" required placeholder="Nama supplier..."
                               class="w-full px-2.5 py-1.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none text-xs font-bold text-gray-800">
                    </div>
                    <div>
                        <label class="block text-[10px] font-bold text-gray-500 uppercase mb-0.5">Asal Bokar *</label>
                        <input type="text" name="origin" id="form_origin" required placeholder="Asal daerah..."
                               class="w-full px-2.5 py-1.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none text-xs font-semibold text-gray-700">
                    </div>
                    <div>
                        <label class="block text-[10px] font-bold text-gray-500 uppercase mb-0.5">No. Kendaraan (Truk) *</label>
                        <input type="text" name="vehicle_number" id="form_vehicle" required placeholder="BL 8255 AB"
                               class="w-full px-2.5 py-1.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none text-xs font-mono font-bold uppercase text-gray-800">
                    </div>
                </div>

                <hr class="border-gray-100 my-1">

                <!-- CONTAINER DINAMIS UNTUK BANYAK PARTAI TIMBANGAN (SESUAI REVISI - BUKAN BANYAK SUPPLIER) -->
                <div id="supplierSectionContainer" class="space-y-3.5">
                    <!-- Section Kelompok timbang dinamis masuk di sini -->
                </div>

                <!-- TOMBOL TAMBAH PARTAI LAIN (Hanya Tampil saat ADD/Tambah Baru) -->
                <div class="pt-1" id="addSupplierBtnContainer">
                    <button type="button" onclick="addSupplierSection('', '')" class="w-full py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-dashed border-indigo-200 font-bold rounded-lg text-xs transition flex justify-center items-center gap-1.5">
                        <i class="fa-solid fa-layer-group"></i> + Tambah Kelompok Timbang Baru pada Truk Ini
                    </button>
                </div>

                <!-- Real-time Grand Total Summary Panel -->
                <div class="bg-primary-50 bg-opacity-60 p-3 rounded-lg border border-primary-100 flex justify-between items-center">
                    <div class="text-[10px] text-gray-500 leading-normal">
                        <p>Total Gross Slip: <span id="calc-gross" class="font-bold">0.0</span> Kg</p>
                        <p>Total Tara Slip: <span id="calc-baskets" class="font-bold text-red-600">0.0</span> Kg</p>
                    </div>
                    <div class="text-right">
                        <p class="text-[10px] text-primary-800 font-bold leading-none">Total Netto Slip</p>
                        <h2 class="text-base font-black text-primary-700 mt-1" id="calc-net">0.0 Kg</h2>
                    </div>
                </div>

                <div class="flex justify-end space-x-2 pt-2 border-t border-gray-100 font-bold">
                    <button type="button" onclick="closeEntryModal()" class="px-3.5 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-lg transition">
                        Batal
                    </button>
                    <button type="submit" id="submitBtn" class="px-3.5 py-1.5 bg-primary-600 hover:bg-primary-700 text-white text-xs rounded-lg shadow-sm transition">
                        Simpan Data
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Scripting for calculations, modal, exports -->
    <script>
        // Elements
        const entryModal = document.getElementById('entryModal');
        const entryModalContainer = document.getElementById('entryModalContainer');
        const entryForm = document.getElementById('entryForm');
        const entryModalTitle = document.getElementById('entryModalTitle');
        const entryAction = document.getElementById('entry_action');
        const editEntryId = document.getElementById('edit_entry_id');
        const formSlip = document.getElementById('form_slip');
        const formDate = document.getElementById('form_date');
        const formVehicle = document.getElementById('form_vehicle');
        const formSupplier = document.getElementById('form_supplier');
        const formOrigin = document.getElementById('form_origin');
        const supplierSectionContainer = document.getElementById('supplierSectionContainer');
        const addSupplierBtnContainer = document.getElementById('addSupplierBtnContainer');
        const submitBtn = document.getElementById('submitBtn');

        const calcGross = document.getElementById('calc-gross');
        const calcBaskets = document.getElementById('calc-baskets');
        const calcNet = document.getElementById('calc-net');

        // Trigger Print (PDF)
        function printPage() {
            const queryParams = new URLSearchParams(new FormData(document.getElementById('filterForm'))).toString();
            window.open('print.php?' + queryParams, '_blank');
        }

        // Trigger Excel export
        function exportExcel() {
            const queryParams = new URLSearchParams(new FormData(document.getElementById('filterForm'))).toString();
            window.location.href = 'export_excel.php?' + queryParams;
        }

        // --- SELECTABLE NOTA PRINTING ---
        function toggleSelectAll(master) {
            const checkboxes = document.querySelectorAll('.slip-checkbox');
            checkboxes.forEach(cb => {
                cb.checked = master.checked;
            });
            updateSelectedCount();
        }

        function updateSelectedCount() {
            const checkedBoxes = document.querySelectorAll('.slip-checkbox:checked');
            const count = checkedBoxes.length;
            const countLabel = document.getElementById('selectedCount');
            const btn = document.getElementById('printNotaBtn');
            const selectAll = document.getElementById('selectAll');
            const totalCheckBoxes = document.querySelectorAll('.slip-checkbox');

            countLabel.textContent = count;

            if (count > 0) {
                btn.disabled = false;
                btn.classList.remove('opacity-60', 'cursor-not-allowed');
                btn.classList.add('opacity-100', 'cursor-pointer');
            } else {
                btn.disabled = true;
                btn.classList.add('opacity-60', 'cursor-not-allowed');
                btn.classList.remove('opacity-100', 'cursor-pointer');
            }

            if (totalCheckBoxes.length > 0) {
                selectAll.checked = (count === totalCheckBoxes.length);
            }
        }

        function printSelectedNotas() {
            const checkedBoxes = document.querySelectorAll('.slip-checkbox:checked');
            if (checkedBoxes.length === 0) {
                alert('Silakan pilih setidaknya satu data slip untuk dicetak!');
                return;
            }

            const ids = Array.from(checkedBoxes).map(cb => cb.value).join(',');
            window.open('print_nota.php?ids=' + ids, '_blank');
        }

        // --- DYNAMIC MULTI-PARTAI TIMBANGAN LOGIC (SESUAI REVISI TERAKHIR) ---
        let supplierCounter = 0; // bertindak sebagai kelompok counter

        function addSupplierSection(kelompokNameVal = "", unusedOrigin = "") {
            const pIdx = supplierCounter; // pIdx = Kelompok Index
            supplierCounter++;
            
            const div = document.createElement('div');
            div.className = 'supplier-section bg-gray-50 border border-gray-200 rounded-xl p-3.5 space-y-2.5 relative transition-all duration-150';
            div.id = `supplier_section_${pIdx}`;
            
            // Tombol hapus blok kelompok (hanya jika kelompok > 1)
            let removeBtn = '';
            if (pIdx > 0) {
                removeBtn = `
                    <button type="button" onclick="removeSupplierSection(${pIdx})" class="bg-red-50 text-red-600 hover:bg-red-100 px-2 py-0.5 rounded text-[9px] font-bold transition flex items-center gap-1">
                        <i class="fa-solid fa-trash-can"></i> Hapus Kelompok
                    </button>
                `;
            }
            
            const placeholderKelompok = `Kelompok ${pIdx + 1}`;
            const actualKelompokValue = kelompokNameVal || placeholderKelompok;
            
            div.innerHTML = `
                <div class="flex justify-between items-center border-b border-gray-200 pb-1.5 mb-1.5">
                    <span class="text-[10px] font-black text-primary-900 uppercase tracking-wider flex items-center gap-1">
                        <i class="fa-solid fa-boxes-stacked"></i> Rincian Timbangan Kelompok #${pIdx + 1}
                    </span>
                    ${removeBtn}
                </div>
                
                <div>
                    <label class="block text-[9px] font-bold text-gray-500 uppercase mb-0.5">Keterangan / Nama Kelompok Timbang *</label>
                    <input type="text" name="kelompok_name[]" value="${actualKelompokValue}" required placeholder="Contoh: Karet Kebun Belakang, Kelompok Harian, dll."
                           class="w-full px-2.5 py-1.5 rounded-lg border border-gray-300 focus:ring-1 focus:ring-primary-500 outline-none text-xs font-bold text-gray-800">
                </div>

                <!-- Tab Buttons per Grade untuk Kelompok ini -->
                <div class="space-y-1.5 pt-1">
                    <div class="flex border border-gray-200 bg-white rounded-t-lg overflow-hidden divide-x divide-gray-100 shadow-sm">
                        <button type="button" onclick="switchSupplierGradeTab(${pIdx}, 'A')" id="tab_btn_a_${pIdx}" class="flex-1 py-1.5 text-center text-[9px] font-extrabold uppercase transition outline-none border-b-2 border-green-600 bg-green-50 bg-opacity-30 text-green-800">
                            Grade A <span id="badge_count_a_${pIdx}" class="ml-0.5 bg-green-100 text-green-800 text-[8px] px-1.5 py-0.2 rounded-full font-mono">1</span>
                        </button>
                        <button type="button" onclick="switchSupplierGradeTab(${pIdx}, 'B')" id="tab_btn_b_${pIdx}" class="flex-1 py-1.5 text-center text-[9px] font-extrabold uppercase transition outline-none border-b-2 border-transparent text-gray-500 hover:bg-gray-50">
                            Grade B <span id="badge_count_b_${pIdx}" class="ml-0.5 bg-gray-200 text-gray-600 text-[8px] px-1.5 py-0.2 rounded-full font-mono">0</span>
                        </button>
                        <button type="button" onclick="switchSupplierGradeTab(${pIdx}, 'C')" id="tab_btn_c_${pIdx}" class="flex-1 py-1.5 text-center text-[9px] font-extrabold uppercase transition outline-none border-b-2 border-transparent text-gray-500 hover:bg-gray-50">
                            Grade C <span id="badge_count_c_${pIdx}" class="ml-0.5 bg-gray-200 text-gray-600 text-[8px] px-1.5 py-0.2 rounded-full font-mono">0</span>
                        </button>
                    </div>
                    
                    <div class="bg-white border border-t-0 border-gray-200 p-2.5 rounded-b-lg space-y-2 shadow-sm">
                        <!-- GRADE A CONTENT -->
                        <div id="tab_content_a_${pIdx}" class="space-y-1.5">
                            <div class="flex justify-between items-center bg-green-50 p-1.5 rounded border border-green-100 leading-none">
                                <span class="text-[8px] font-bold text-green-800 uppercase tracking-wider">Timbangan Grade A</span>
                                <button type="button" onclick="addBasketToSupplierGrade(${pIdx}, 'A', '', '15.0')" class="bg-green-600 hover:bg-green-700 text-white font-bold px-2 py-0.5 rounded text-[8px] transition">
                                    + Keranjang A
                                </button>
                            </div>
                            <div class="flex items-center gap-1 px-1.5 text-[8px] font-bold text-gray-400 uppercase leading-none">
                                <div class="w-10">Wadah</div>
                                <div class="flex-grow grid grid-cols-2 gap-1.5 text-center">
                                    <div>Gross (Kotor)</div>
                                    <div>Tara (Wadah)</div>
                                </div>
                                <div class="w-5"></div>
                            </div>
                            <div id="container_a_${pIdx}" class="space-y-1 max-h-32 overflow-y-auto pr-0.5"></div>
                        </div>
                        
                        <!-- GRADE B CONTENT -->
                        <div id="tab_content_b_${pIdx}" class="space-y-1.5 hidden">
                            <div class="flex justify-between items-center bg-blue-50 p-1.5 rounded border border-blue-100 leading-none">
                                <span class="text-[8px] font-bold text-blue-800 uppercase tracking-wider">Timbangan Grade B</span>
                                <button type="button" onclick="addBasketToSupplierGrade(${pIdx}, 'B', '', '15.0')" class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-2 py-0.5 rounded text-[8px] transition">
                                    + Keranjang B
                                </button>
                            </div>
                            <div class="flex items-center gap-1 px-1.5 text-[8px] font-bold text-gray-400 uppercase leading-none">
                                <div class="w-10">Wadah</div>
                                <div class="flex-grow grid grid-cols-2 gap-1.5 text-center">
                                    <div>Gross (Kotor)</div>
                                    <div>Tara (Wadah)</div>
                                </div>
                                <div class="w-5"></div>
                            </div>
                            <div id="container_b_${pIdx}" class="space-y-1 max-h-32 overflow-y-auto pr-0.5"></div>
                        </div>
                        
                        <!-- GRADE C CONTENT -->
                        <div id="tab_content_c_${pIdx}" class="space-y-1.5 hidden">
                            <div class="flex justify-between items-center bg-yellow-50 p-1.5 rounded border border-yellow-100 leading-none">
                                <span class="text-[8px] font-bold text-yellow-800 uppercase tracking-wider">Timbangan Grade C</span>
                                <button type="button" onclick="addBasketToSupplierGrade(${pIdx}, 'C', '', '15.0')" class="bg-yellow-600 hover:bg-yellow-700 text-white font-bold px-2 py-0.5 rounded text-[8px] transition">
                                    + Keranjang C
                                </button>
                            </div>
                            <div class="flex items-center gap-1 px-1.5 text-[8px] font-bold text-gray-400 uppercase leading-none">
                                <div class="w-10">Wadah</div>
                                <div class="flex-grow grid grid-cols-2 gap-1.5 text-center">
                                    <div>Gross (Kotor)</div>
                                    <div>Tara (Wadah)</div>
                                </div>
                                <div class="w-5"></div>
                            </div>
                            <div id="container_c_${pIdx}" class="space-y-1 max-h-32 overflow-y-auto pr-0.5"></div>
                        </div>
                    </div>
                </div>

                <!-- Sub-total Bersih untuk Kelompok ini -->
                <div class="bg-primary-50 bg-opacity-35 p-2 rounded-lg border border-primary-100 flex justify-between items-center text-[10px] leading-none">
                    <span class="font-bold text-primary-800">Subtotal Bersih Kelompok #${pIdx + 1}:</span>
                    <span class="font-black text-primary-900"><span id="supplier_net_${pIdx}">0.0</span> Kg</span>
                </div>
            `;
            
            supplierSectionContainer.appendChild(div);
            
            // Tambahkan 1 keranjang awal Grade A
            addBasketToSupplierGrade(pIdx, 'A', '', '15.0');
            switchSupplierGradeTab(pIdx, 'A');
            
            calculateRealtime();
        }

        function removeSupplierSection(idx) {
            const section = document.getElementById(`supplier_section_${idx}`);
            if (section) {
                section.remove();
                calculateRealtime();
            }
        }

        // Switch Tab per Kelompok
        function switchSupplierGradeTab(pIdx, grade) {
            const grades = ['A', 'B', 'C'];
            grades.forEach(g => {
                const btn = document.getElementById(`tab_btn_${g.toLowerCase()}_${pIdx}`);
                const content = document.getElementById(`tab_content_${g.toLowerCase()}_${pIdx}`);
                
                if (g === grade) {
                    content.classList.remove('hidden');
                    if (g === 'A') {
                        btn.className = "flex-1 py-1.5 text-center text-[9px] font-extrabold uppercase transition outline-none border-b-2 border-green-600 bg-green-50 bg-opacity-30 text-green-800";
                    } else if (g === 'B') {
                        btn.className = "flex-1 py-1.5 text-center text-[9px] font-extrabold uppercase transition outline-none border-b-2 border-blue-600 bg-blue-50 bg-opacity-30 text-blue-800";
                    } else if (g === 'C') {
                        btn.className = "flex-1 py-1.5 text-center text-[9px] font-extrabold uppercase transition outline-none border-b-2 border-yellow-600 bg-yellow-50 bg-opacity-30 text-yellow-800";
                    }
                } else {
                    content.classList.add('hidden');
                    btn.className = "flex-1 py-1.5 text-center text-[9px] font-extrabold uppercase transition outline-none border-b-2 border-transparent text-gray-500 hover:bg-gray-100";
                }
            });
        }

        // Add Basket Row per Kelompok per Grade Section
        function addBasketToSupplierGrade(pIdx, grade, grossVal = "", taraVal = "") {
            const container = document.getElementById(`container_${grade.toLowerCase()}_${pIdx}`);
            const uniqueId = `basket_row_${pIdx}_${grade.toLowerCase()}_` + Math.random().toString(36).substr(2, 9);
            
            const row = document.createElement('div');
            
            let borderAccent = 'border-l-4 border-l-green-500 border-green-200';
            if (grade === 'B') borderAccent = 'border-l-4 border-l-blue-500 border-blue-200';
            if (grade === 'C') borderAccent = 'border-l-4 border-l-yellow-500 border-yellow-200';
            
            row.className = `basket-item flex items-center gap-1.5 bg-white p-1.5 rounded-lg border ${borderAccent} shadow-xs transition-all duration-150`;
            row.id = uniqueId;
            
            row.innerHTML = `
                <span class="basket-label text-[9px] font-bold text-primary-800 font-mono w-10">Kj 1</span>
                <div class="flex-grow grid grid-cols-2 gap-1.5 font-bold text-gray-900">
                    <input type="number" step="0.1" min="0.1" name="gross_weights_${grade.toLowerCase()}_${pIdx}[]" value="${grossVal}" placeholder="Gross" required
                           class="w-full px-2 py-0.5 rounded border border-gray-300 focus:ring-1 focus:ring-primary-500 outline-none text-xs text-right"
                           oninput="calculateRealtime()">
                    <input type="number" step="0.1" min="0" name="basket_weights_${grade.toLowerCase()}_${pIdx}[]" value="${taraVal}" placeholder="Tara" required
                           class="w-full px-2 py-0.5 rounded border border-gray-300 focus:ring-1 focus:ring-primary-500 outline-none text-xs font-semibold text-gray-600 text-right"
                           oninput="calculateRealtime()">
                </div>
                <button type="button" onclick="removeBasketInput('${uniqueId}', ${pIdx})" class="text-red-500 hover:text-red-700 p-0.5 hover:bg-red-50 rounded transition">
                    <i class="fa-solid fa-trash text-[10px]"></i>
                </button>
            `;
            
            container.appendChild(row);
            reindexBasketsForSupplierGrade(pIdx, grade);
            calculateRealtime();
        }

        function removeBasketInput(id, pIdx) {
            const row = document.getElementById(id);
            if (row) {
                const gradeLetter = id.split('_')[3].toUpperCase();
                row.remove();
                reindexBasketsForSupplierGrade(pIdx, gradeLetter);
                calculateRealtime();
            }
        }

        function reindexBasketsForSupplierGrade(pIdx, grade) {
            const container = document.getElementById(`container_${grade.toLowerCase()}_${pIdx}`);
            const rows = container.querySelectorAll('.basket-item');
            rows.forEach((row, index) => {
                const label = row.querySelector('.basket-label');
                if (label) {
                    label.textContent = `Kj ${index + 1}`;
                }
            });
            
            // Perbarui Angka Badge Count pada Tab secara interaktif
            const badge = document.getElementById(`badge_count_${grade.toLowerCase()}_${pIdx}`);
            if (badge) {
                badge.textContent = rows.length;
                if (rows.length > 0) {
                    badge.className = `ml-0.5 text-[8px] px-1.5 py-0.2 rounded-full font-mono font-bold ${grade === 'A' ? 'bg-green-100 text-green-800' : (grade === 'B' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800')}`;
                } else {
                    badge.className = "ml-0.5 bg-gray-200 text-gray-600 text-[8px] px-1.5 py-0.2 rounded-full font-mono";
                }
            }
        }

        // Real-time Calculations for ALL kelompoks
        function calculateRealtime() {
            let grandGross = 0;
            let grandTara = 0;
            
            const activeKelompoks = supplierSectionContainer.querySelectorAll('.supplier-section');
            activeKelompoks.forEach(section => {
                const pIdx = parseInt(section.id.split('_')[2]);
                
                let supplierGross = 0;
                let supplierTara = 0;
                
                // Calculate Grade A
                const rowsA = document.getElementById(`container_a_${pIdx}`).querySelectorAll('.basket-item');
                rowsA.forEach(row => {
                    const gVal = parseFloat(row.querySelector(`input[name="gross_weights_a_${pIdx}[]"]`).value) || 0;
                    const tVal = parseFloat(row.querySelector(`input[name="basket_weights_a_${pIdx}[]"]`).value) || 0;
                    supplierGross += gVal;
                    supplierTara += tVal;
                });
                
                // Calculate Grade B
                const rowsB = document.getElementById(`container_b_${pIdx}`).querySelectorAll('.basket-item');
                rowsB.forEach(row => {
                    const gVal = parseFloat(row.querySelector(`input[name="gross_weights_b_${pIdx}[]"]`).value) || 0;
                    const tVal = parseFloat(row.querySelector(`input[name="basket_weights_b_${pIdx}[]"]`).value) || 0;
                    supplierGross += gVal;
                    supplierTara += tVal;
                });
                
                // Calculate Grade C
                const rowsC = document.getElementById(`container_c_${pIdx}`).querySelectorAll('.basket-item');
                rowsC.forEach(row => {
                    const gVal = parseFloat(row.querySelector(`input[name="gross_weights_c_${pIdx}[]"]`).value) || 0;
                    const tVal = parseFloat(row.querySelector(`input[name="basket_weights_c_${pIdx}[]"]`).value) || 0;
                    supplierGross += gVal;
                    supplierTara += tVal;
                });
                
                const supplierNet = Math.max(0, supplierGross - supplierTara);
                
                // Update subtotal bersih kelompok di modal
                document.getElementById(`supplier_net_${pIdx}`).textContent = supplierNet.toFixed(1);
                
                grandGross += supplierGross;
                grandTara += supplierTara;
            });
            
            const grandNet = Math.max(0, grandGross - grandTara);
            
            calcGross.textContent = grandGross.toFixed(1);
            calcBaskets.textContent = grandTara.toFixed(1);
            calcNet.textContent = `${grandNet.toFixed(1)} Kg`;
            
            if (grandNet <= 0 && grandGross > 0) {
                calcNet.className = "text-base font-black text-red-600 animate-pulse";
            } else {
                calcNet.className = "text-base font-black text-primary-700";
            }
        }

        // Modal opens (Inisialisasi form Tambah Baru)
        function openAddEntryModal(nextSlip) {
            entryModalTitle.textContent = "Tambah Rekap Bokar Baru";
            entryAction.value = "add";
            editEntryId.value = "";
            
            formSlip.value = nextSlip;
            
            const today = new Date().toISOString().split('T')[0];
            formDate.value = today;
            
            formVehicle.value = ""; // Bersihkan No. Polisi Truk
            formSupplier.value = ""; // Bersihkan Nama Supplier
            formOrigin.value = ""; // Bersihkan Asal Daerah
            
            // Bersihkan kontainer dan reset counter kelompok
            supplierSectionContainer.innerHTML = "";
            supplierCounter = 0;
            
            // Tampilkan tombol tambah kelompok
            addSupplierBtnContainer.classList.remove('hidden');
            
            // Tambahkan kelompok pertama secara otomatis
            addSupplierSection("Kelompok 1", "");
            
            calculateRealtime();
            
            entryModal.classList.remove('hidden');
            setTimeout(() => {
                entryModalContainer.classList.replace('scale-95', 'scale-100');
                entryModalContainer.classList.replace('opacity-0', 'opacity-100');
            }, 10);
        }

        function closeEntryModal() {
            entryModalContainer.classList.replace('scale-100', 'scale-95');
            entryModalContainer.classList.replace('opacity-100', 'opacity-0');
            setTimeout(() => {
                entryModal.classList.add('hidden');
            }, 150);
        }

        // Edit entry populated (Hanya edit 1 Kelompok)
        function editEntry(entry) {
            entryModalTitle.textContent = "Ubah Data Rekap Bokar";
            entryAction.value = "edit";
            editEntryId.value = entry.id;
            
            formSlip.value = entry.slip_number;
            formDate.value = entry.created_at.substring(0, 10);
            formVehicle.value = entry.vehicle_number;
            formSupplier.value = entry.supplier_name;
            formOrigin.value = entry.origin;
            
            // Bersihkan kontainer dan reset counter
            supplierSectionContainer.innerHTML = "";
            supplierCounter = 0;
            
            // Sembunyikan tombol tambah kelompok saat edit
            addSupplierBtnContainer.classList.add('hidden');
            
            // Buat satu seksi kelompok timbang
            const kelompokName = entry.kelompoks_list[0] || "Kelompok 1";
            addSupplierSection(kelompokName, "");
            
            // Bersihkan timbangan otomatis default dan muat timbangan rill dari DB
            document.getElementById('container_a_0').innerHTML = "";
            document.getElementById('container_b_0').innerHTML = "";
            document.getElementById('container_c_0').innerHTML = "";
            
            if (entry.gross_list && entry.gross_list.length > 0) {
                for (let i = 0; i < entry.gross_list.length; i++) {
                    const grossVal = entry.gross_list[i] || "";
                    const taraVal = entry.baskets_list[i] || "";
                    const gradeVal = entry.grades_list[i] || "Grade A";
                    
                    let letter = 'A';
                    if (gradeVal === 'Grade B') letter = 'B';
                    if (gradeVal === 'Grade C') letter = 'C';
                    
                    addBasketToSupplierGrade(0, letter, grossVal, taraVal);
                }
            } else {
                addBasketToSupplierGrade(0, 'A', '', '15.0');
            }
            
            // Buka Tab pertama yang memiliki data timbangan
            if (document.getElementById('container_a_0').children.length > 0) {
                switchSupplierGradeTab(0, 'A');
            } else if (document.getElementById('container_b_0').children.length > 0) {
                switchSupplierGradeTab(0, 'B');
            } else if (document.getElementById('container_c_0').children.length > 0) {
                switchSupplierGradeTab(0, 'C');
            } else {
                switchSupplierGradeTab(0, 'A');
            }
            
            calculateRealtime();
            
            entryModal.classList.remove('hidden');
            setTimeout(() => {
                entryModalContainer.classList.replace('scale-95', 'scale-100');
                entryModalContainer.classList.replace('opacity-0', 'opacity-100');
            }, 10);
        }
    </script>
</body>
</html>
