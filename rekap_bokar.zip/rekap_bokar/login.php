<?php
// login.php
require_once 'config.php';

if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim(strtolower($_POST['username']));
    $password = $_POST['password'];
    
    if (!empty($username) && !empty($password)) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['fullname'] = $user['fullname'];
            $_SESSION['role'] = $user['role'];
            
            set_flash('success', 'Selamat datang kembali, ' . $user['fullname'] . '!');
            header("Location: index.php");
            exit;
        } else {
            $error = 'Username atau password salah.';
        }
    } else {
        $error = 'Harap isi semua kolom.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Rekapitulasi Bokar</title>
    <!-- Tailwind CSS CDN -->
    <link rel="stylesheet" href="assets/css/tailwind.css">
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
</head>
<body class="bg-gray-50 text-gray-800 flex flex-col min-h-screen font-sans">

    <!-- Header / Navbar -->
    <header class="bg-primary-800 text-white shadow-md">
        <div class="container mx-auto px-4 py-3 flex justify-between items-center">
            <div class="flex items-center space-x-3">
                <div class="bg-white p-2 rounded-full text-primary-800">
                    <i class="fa-solid fa-tree text-xl"></i>
                </div>
                <div>
                    <h1 class="text-xl font-bold tracking-tight">Rekapitulasi Bokar</h1>
                    <p class="text-xs text-primary-200">PT Potensi Bumi Sakti (Arsari Group)</p>
                </div>
            </div>
        </div>
    </header>

    <main class="flex-grow flex items-center justify-center px-4 py-12">
        <div class="max-w-md w-full bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
            <div class="bg-primary-800 text-white p-6 text-center">
                <i class="fa-solid fa-tree text-4xl mb-2"></i>
                <h2 class="text-2xl font-bold">Selamat Datang</h2>
                <p class="text-sm text-primary-200 mt-1">Sistem Rekapitulasi Bahan Olahan Karet (Bokar)</p>
            </div>
            
            <form action="login.php" method="POST" class="p-8 space-y-6">
                <?php if (!empty($error)): ?>
                    <div class="p-4 bg-red-50 border border-red-200 text-red-800 rounded-xl text-sm flex items-start space-x-2">
                        <i class="fa-solid fa-circle-exclamation text-lg mt-0.5"></i>
                        <span><?php echo htmlspecialchars($error); ?></span>
                    </div>
                <?php endif; ?>

                <?php display_flash(); ?>

                <div>
                    <label for="username" class="block text-sm font-semibold text-gray-700 mb-1.5 flex items-center gap-2">
                        <i class="fa-solid fa-user text-gray-400"></i> Nama Pengguna (Username)
                    </label>
                    <input type="text" name="username" id="username" required placeholder="Masukkan username..." 
                           class="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition text-sm">
                </div>
                
                <div>
                    <label for="password" class="block text-sm font-semibold text-gray-700 mb-1.5 flex items-center gap-2">
                        <i class="fa-solid fa-lock text-gray-400"></i> Kata Sandi (Password)
                    </label>
                    <input type="password" name="password" id="password" required placeholder="Masukkan password..." 
                           class="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition text-sm">
                </div>
                
                <button type="submit" class="w-full py-3 bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-lg shadow-md hover:shadow-lg transition flex justify-center items-center gap-2">
                    <i class="fa-solid fa-right-to-bracket"></i> Masuk ke Sistem
                </button>
            </form>

        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-800 text-gray-400 py-6 mt-auto border-t border-gray-700">
        <div class="container mx-auto px-4 text-center text-sm">
            <p class="font-semibold text-gray-300">Sistem Informasi Rekapitulasi Bokar (Bahan Olahan Karet)</p>
            <p class="text-xs mt-1">&copy; 2026 PT Potensi Bumi Sakti (Arsari Group). All rights reserved.</p>
        </div>
    </footer>

</body>
</html>
